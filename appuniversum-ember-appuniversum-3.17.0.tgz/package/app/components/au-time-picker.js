export { default } from '@appuniversum/ember-appuniversum/components/au-time-picker';
