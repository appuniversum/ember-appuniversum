// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface LockOpenIconSignature {
  Element: SVGSVGElement;
}

export const LockOpenIcon: TOC<LockOpenIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12,4 C10.3523,4 9,5.35228 9,7 L9,10 L18,10 C19.1046,10 20,10.8954 20,12 L20,20 C20,21.1046 19.1046,22 18,22 L6,22 C4.89543,22 4,21.1046 4,20 L4,12 C4,10.8954 4.89543,10 6,10 L7,10 L7,7 C7,4.24772 9.24771,2 12,2 C14.7523,2 17,4.24772 17,7 C17,7.55228 16.5523,8 16,8 C15.4477,8 15,7.55228 15,7 C15,5.35228 13.6477,4 12,4 Z M6,12 L6,20 L18,20 L18,12 L6,12 Z" fill-rule="evenodd"/></svg></template>;