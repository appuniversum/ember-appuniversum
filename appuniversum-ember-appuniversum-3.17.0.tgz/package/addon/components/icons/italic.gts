// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ItalicIconSignature {
  Element: SVGSVGElement;
}

export const ItalicIcon: TOC<ItalicIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="21 4.0755 21 2.0755 11 2.0755 11 4.0755 14.461 4.0755 7.351 20.0755 3 20.0755 3 22.0755 13 22.0755 13 20.0755 9.539 20.0755 16.649 4.0755"/></svg>
</template>;