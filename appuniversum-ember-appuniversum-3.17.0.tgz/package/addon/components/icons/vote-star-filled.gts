// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface VoteStarFilledIconSignature {
  Element: SVGSVGElement;
}

export const VoteStarFilledIcon: TOC<VoteStarFilledIconSignature> = <template><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 17" ...attributes><path d="M12 15.167a.668.668 0 0 1-.37-.112L8 12.635l-3.63 2.42a.667.667 0 0 1-1.01-.737l1.225-4.29-3.056-3.056A.668.668 0 0 1 2 5.834h3.588l1.816-3.631c.226-.452.967-.452 1.193 0l1.816 3.631H14a.667.667 0 0 1 .471 1.138l-3.056 3.056 1.226 4.29a.667.667 0 0 1-.641.85Z"/></svg>
</template>;