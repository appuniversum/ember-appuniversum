// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface MenuIconSignature {
  Element: SVGSVGElement;
}

export const MenuIcon: TOC<MenuIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M20 5H4V7H20V5ZM20 8.999H4V10.999H20V8.999ZM4 13H20V15H4V13ZM20 17H4V19H20V17Z" />
</svg>
</template>;