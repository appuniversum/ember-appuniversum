// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface DocumentIconSignature {
  Element: SVGSVGElement;
}

export const DocumentIcon: TOC<DocumentIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M6,2 C4.89543,2 4,2.89543 4,4 L4,20 C4,21.1046 4.89543,22 6,22 L18,22 C19.1046,22 20,21.1046 20,20 L20,8 C20,7.73478 19.8946,7.48043 19.7071,7.29289 L14.7071,2.29289 C14.5196,2.10536 14.2652,2 14,2 L6,2 Z M12,4 L12,9 C12,9.55228 12.4477,10 13,10 L18,10 L18,20 L6,20 L6,4 L12,4 Z M17.5858,8 L14,8 L14,4.41421 L17.5858,8 Z"/></svg></template>;