// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CheckFilledIconSignature {
  Element: SVGSVGElement;
}

export const CheckFilledIcon: TOC<CheckFilledIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M2 12C2 17.515 6.486 22 12 22C17.514 22 22 17.515 22 12C22 6.486 17.514 2 12 2C6.486 2 2 6.486 2 12ZM5.8 13.6L10.6 17.4L17.6 9.2L16 8L10.2 14.6L7 12L5.8 13.6Z" />
</svg>
</template>;