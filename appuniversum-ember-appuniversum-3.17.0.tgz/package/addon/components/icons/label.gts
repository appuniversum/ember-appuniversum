// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface LabelIconSignature {
  Element: SVGSVGElement;
}

export const LabelIcon: TOC<LabelIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M14.63,0.84 C14.27,0.33 13.67,0 13,0 L2,0.01 C0.9,0.01 0,0.9 0,2 L0,12 C0,13.1 0.9,13.99 2,13.99 L13,14 C13.67,14 14.27,13.67 14.63,13.16 L19,7 L14.63,0.84 Z" transform="translate(2.5 5)"/></svg></template>;