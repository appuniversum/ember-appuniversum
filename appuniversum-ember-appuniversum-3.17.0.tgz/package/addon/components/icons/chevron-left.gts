// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ChevronLeftIconSignature {
  Element: SVGSVGElement;
}

export const ChevronLeftIcon: TOC<ChevronLeftIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="15.5 20.4 7.1 12 15.5 3.6 16.9 5 9.9 12 16.9 19"/></svg></template>;