// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface LinkExternalIconSignature {
  Element: SVGSVGElement;
}

export const LinkExternalIcon: TOC<LinkExternalIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M18.6005,3.974775 L15.3619,3.974775 L15.3336,1.994875 L21.9946,1.994875 L22.0158,8.634605 L20.0147,8.627535 L20.0147,5.388985 L12.0217,13.381725 L10.6075,11.967525 L18.6005,3.974775 Z M13.2967,5.005125 L1.9842,5.005125 L1.9842,22.005125 L18.9842,22.005125 L18.9842,10.692625 L16.9842,10.692625 L16.9842,20.005125 L3.9842,20.005125 L3.9842,7.005125 L13.2967,7.005125 L13.2967,5.005125 Z"/></svg></template>;