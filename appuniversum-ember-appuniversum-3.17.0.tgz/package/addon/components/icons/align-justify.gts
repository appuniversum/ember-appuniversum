// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface AlignJustifyIconSignature {
  Element: SVGSVGElement;
}

export const AlignJustifyIcon: TOC<AlignJustifyIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M2 3H22V5H2V3ZM2 7H22V9H2V7ZM22 11H2V13H22V11ZM2 15H22V17H2V15ZM16 19H2V21H16V19Z" />
</svg>
</template>;