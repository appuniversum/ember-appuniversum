// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface UserIconSignature {
  Element: SVGSVGElement;
}

export const UserIcon: TOC<UserIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12,4 C9.79086,4 8,5.79086 8,8 C8,10.2091 9.79086,12 12,12 C14.2091,12 16,10.2091 16,8 C16,5.79086 14.2091,4 12,4 Z M6,8 C6,4.68629 8.68629,2 12,2 C15.3137,2 18,4.68629 18,8 C18,11.3137 15.3137,14 12,14 C8.68629,14 6,11.3137 6,8 Z M8,18 C6.34315,18 5,19.3431 5,21 C5,21.5523 4.55228,22 4,22 C3.44772,22 3,21.5523 3,21 C3,18.2386 5.23858,16 8,16 L16,16 C18.7614,16 21,18.2386 21,21 C21,21.5523 20.5523,22 20,22 C19.4477,22 19,21.5523 19,21 C19,19.3431 17.6569,18 16,18 L8,18 Z"/></svg></template>;