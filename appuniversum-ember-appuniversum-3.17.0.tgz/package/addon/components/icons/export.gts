// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ExportIconSignature {
  Element: SVGSVGElement;
}

export const ExportIcon: TOC<ExportIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M16.8553821,9 L16.8553821,18.2 L19.1453821,15.91 L20.5653821,17.29 L15.8553821,22 L11.1453821,17.32 L12.5653821,15.91 L14.8553821,18.2 L14.8553821,9 L16.8553821,9 Z M8.14461786,2 L12.8546179,6.71 L11.4346179,8.12 L9.14461786,5.83 L9.14461786,15 L7.14461786,15 L7.14461786,5.83 L4.85461786,8.12 L3.43461786,6.71 L8.14461786,2 Z"/></svg></template>;