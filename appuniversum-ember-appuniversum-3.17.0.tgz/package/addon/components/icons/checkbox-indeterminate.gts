// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CheckboxIndeterminateIconSignature {
  Element: SVGSVGElement;
}

export const CheckboxIndeterminateIcon: TOC<CheckboxIndeterminateIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M19.0001808,3 L5.00018082,3 C3.90018082,3 3.00018082,3.9 3.00018082,5 L3.00018082,19 C3.00018082,20.1 3.90018082,21 5.00018082,21 L19.0001808,21 C20.1001808,21 21.0001808,20.1 21.0001808,19 L21.0001808,5 C21.0001808,3.9 20.1001808,3 19.0001808,3 Z M17.0001808,13 L7.00018082,13 L7.00018082,11 L17.0001808,11 L17.0001808,13 Z"/></svg></template>;