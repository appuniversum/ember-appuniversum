// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface UnderlinedIconSignature {
  Element: SVGSVGElement;
}

export const UnderlinedIcon: TOC<UnderlinedIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M14,4 L14,2 L20,2 L20,4 L18,4 L18,12 C18,15.309 15.309,18 12,18 C8.691,18 6,15.309 6,12 L6,4 L4,4 L4,2 L10,2 L10,4 L8,4 L8,12 C8,14.206 9.794,16 12,16 C14.206,16 16,14.206 16,12 L16,4 L14,4 Z M20,22 L20,20 L4,20 L4,22 L20,22 Z" fill-rule="evenodd"/></svg>
</template>;