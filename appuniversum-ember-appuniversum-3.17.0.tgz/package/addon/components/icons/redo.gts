// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface RedoIconSignature {
  Element: SVGSVGElement;
}

export const RedoIcon: TOC<RedoIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M21.7005,6.305 L20.1195,9.042 C18.8555,4.969 15.0515,2 10.5665,2 C5.0525,2 0.5665,6.486 0.5665,12 C0.5665,17.515 5.0525,22 10.5665,22 L10.5665,20 C6.1555,20 2.5665,16.411 2.5665,12 C2.5665,7.589 6.1555,4 10.5665,4 C14.3355,4 17.4955,6.623 18.3385,10.136 L14.8705,8.134 L13.8705,9.867 L19.9335,13.367 L23.4335,7.305 L21.7005,6.305 Z"/></svg></template>;