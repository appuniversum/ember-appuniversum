// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ThreeDotsIconSignature {
  Element: SVGSVGElement;
}

export const ThreeDotsIcon: TOC<ThreeDotsIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M6,10 C7.10457,10 8,10.8954 8,12 C8,13.1046 7.10457,14 6,14 C4.89543,14 4,13.1046 4,12 C4,10.8954 4.89543,10 6,10 Z M12,10 C13.1046,10 14,10.8954 14,12 C14,13.1046 13.1046,14 12,14 C10.8954,14 10,13.1046 10,12 C10,10.8954 10.8954,10 12,10 Z M18,10 C19.1046,10 20,10.8954 20,12 C20,13.1046 19.1046,14 18,14 C16.8954,14 16,13.1046 16,12 C16,10.8954 16.8954,10 18,10 Z"/></svg></template>;