// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CircleInfoIconSignature {
  Element: SVGSVGElement;
}

export const CircleInfoIcon: TOC<CircleInfoIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12,22 C6.486,22 2,17.515 2,12 C2,6.487 6.486,2 12,2 C17.514,2 22,6.486 22,12 C22,17.515 17.514,22 12,22 Z M12,4 C7.589,4 4,7.589 4,12 C4,16.411 7.589,20 12,20 C16.411,20 20,16.411 20,12 C20,7.589 16.411,4 12,4 Z M13,15 L15,15 L15,17 L9,17 L9,15 L11,15 L11,12 L10,12 L10,10 L12,10 C12.553,10 13,10.448 13,11 L13,15 Z M12,9.25 C11.3096,9.25 10.75,8.69036 10.75,8 C10.75,7.30964 11.3096,6.75 12,6.75 C12.6904,6.75 13.25,7.30964 13.25,8 C13.25,8.69036 12.6904,9.25 12,9.25 Z"/></svg></template>;