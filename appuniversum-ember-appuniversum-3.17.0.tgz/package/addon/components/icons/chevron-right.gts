// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ChevronRightIconSignature {
  Element: SVGSVGElement;
}

export const ChevronRightIcon: TOC<ChevronRightIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="8.499955 20.4 7.099955 19 14.100045 12 7.099955 5 8.499955 3.6 16.900045 12"/></svg></template>;