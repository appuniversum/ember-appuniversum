// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface NavDownDoubleIconSignature {
  Element: SVGSVGElement;
}

export const NavDownDoubleIcon: TOC<NavDownDoubleIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M0,1.4 L8.4,9.8 L16.8,1.4 L15.4,0 L8.4,7 L1.4,0 L0,1.4 Z M0,6.4 L8.4,14.8 L16.8,6.4 L15.4,5 L8.4,12 L1.4,5 L0,6.4 Z" transform="translate(3.6 4.6)" fill-rule="evenodd"/></svg></template>;