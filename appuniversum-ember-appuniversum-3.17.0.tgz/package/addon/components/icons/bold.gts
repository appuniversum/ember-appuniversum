// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface BoldIconSignature {
  Element: SVGSVGElement;
}

export const BoldIcon: TOC<BoldIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M16.507,10.556 C17.427,9.649 18,8.391 18,7 C18,4.243 15.757,2 13,2 L4,2 L4,4 L6,4 L6,20 L4,20 L4,22 L14,22 C17.309,22 20,19.309 20,16 C20,13.587 18.565,11.508 16.507,10.556 Z M13,4 C14.654,4 16,5.346 16,7 C16,8.654 14.654,10 13,10 L8,10 L8,4 L13,4 Z M8,20 L14,20 C16.206,20 18,18.206 18,16 C18,13.794 16.206,12 14,12 L8,12 L8,20 Z" fill-rule="evenodd"/></svg>
</template>;