// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface AlignRightIconSignature {
  Element: SVGSVGElement;
}

export const AlignRightIcon: TOC<AlignRightIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M4 3H22V5H4V3ZM8 7H22V9H8V7ZM22 11H2V13H22V11ZM8 15H22V17H8V15ZM22 19H4V21H22V19Z" />
</svg>
</template>;