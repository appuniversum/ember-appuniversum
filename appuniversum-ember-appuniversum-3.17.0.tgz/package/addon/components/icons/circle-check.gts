// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CircleCheckIconSignature {
  Element: SVGSVGElement;
}

export const CircleCheckIcon: TOC<CircleCheckIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12,2 C17.5228,2 22,6.47715 22,12 C22,17.5228 17.5228,22 12,22 C6.47715,22 2,17.5228 2,12 C2,6.47715 6.47715,2 12,2 Z M12,4 C7.58172,4 4,7.58172 4,12 C4,16.4183 7.58172,20 12,20 C16.4183,20 20,16.4183 20,12 C20,7.58172 16.4183,4 12,4 Z M16.293,7.79297 L17.7072,9.20718 L10.0001,16.9143 L6.29297,13.2072 L7.70718,11.793 L10.0001,14.0859 L16.293,7.79297 Z"/></svg></template>;