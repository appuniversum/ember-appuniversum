// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface AlignLeftIconSignature {
  Element: SVGSVGElement;
}

export const AlignLeftIcon: TOC<AlignLeftIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M2 3H20V5H2V3ZM2 7H16V9H2V7ZM22 11H2V13H22V11ZM2 15H16V17H2V15ZM20 19H2V21H20V19Z" />
</svg>
</template>;