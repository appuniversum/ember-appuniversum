// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface DragHandleIconSignature {
  Element: SVGSVGElement;
}

export const DragHandleIcon: TOC<DragHandleIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M20,6 L4,6 L4,8 L20,8 L20,6 Z M4,11 L20,11 L20,13 L4,13 L4,11 Z M4,16 L20,16 L20,18 L4,18 L4,16 Z" fill-rule="evenodd"/></svg></template>;