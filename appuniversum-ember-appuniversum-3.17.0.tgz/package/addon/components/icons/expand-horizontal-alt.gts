// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ExpandHorizontalAltIconSignature {
  Element: SVGSVGElement;
}

export const ExpandHorizontalAltIcon: TOC<ExpandHorizontalAltIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M1.586 11.999L8.293 5.29199L9.707 6.70599L4.414 11.999L9.707 17.292L8.293 18.706L1.586 11.999ZM19.586 11.999L14.293 6.70599L15.707 5.29199L22.414 11.999L15.707 18.706L14.293 17.292L19.586 11.999Z" />
</svg>
</template>;