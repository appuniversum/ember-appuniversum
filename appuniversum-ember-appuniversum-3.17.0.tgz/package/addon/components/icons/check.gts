// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CheckIconSignature {
  Element: SVGSVGElement;
}

export const CheckIcon: TOC<CheckIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="21.207115 6.353545 8.499995 19.060665 2.792885 13.353565 4.207095 11.939365 8.499995 16.232265 19.792915 4.939335"/></svg></template>;