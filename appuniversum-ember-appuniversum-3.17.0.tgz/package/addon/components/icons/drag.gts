// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface DragIconSignature {
  Element: SVGSVGElement;
}

export const DragIcon: TOC<DragIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M8,5.5 L11,5.5 L11,8.5 L8,8.5 L8,5.5 Z M8,10.5 L11,10.5 L11,13.5 L8,13.5 L8,10.5 Z M11,15.5 L8,15.5 L8,18.5 L11,18.5 L11,15.5 Z M16,15.5 L13,15.5 L13,18.5 L16,18.5 L16,15.5 Z M16,10.5 L13,10.5 L13,13.5 L16,13.5 L16,10.5 Z M16,5.5 L13,5.5 L13,8.5 L16,8.5 L16,5.5 Z"/></svg></template>;