// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface FilterIconSignature {
  Element: SVGSVGElement;
}

export const FilterIcon: TOC<FilterIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M5,4 L7,4 L7,6 L9,6 L9,8 L7,8 L7,20 L5,20 L5,8 L3,8 L3,6 L5,6 L5,4 Z M11,4 L13,4 L13,11 L15,11 L15,13 L13,13 L13,20 L11,20 L11,13 L9,13 L9,11 L11,11 L11,4 Z M19,4 L17,4 L17,16 L15,16 L15,18 L17,18 L17,20 L19,20 L19,18 L21,18 L21,16 L19,16 L19,4 Z"/></svg></template>;