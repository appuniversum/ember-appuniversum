// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CloseFilledIconSignature {
  Element: SVGSVGElement;
}

export const CloseFilledIcon: TOC<CloseFilledIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path d="M12 2.00101C6.486 2.00101 2 6.48701 2 12.001C2 17.515 6.486 22.001 12 22.001C17.514 22.001 22 17.515 22 12.001C22 6.48701 17.514 2.00101 12 2.00101ZM16.707 15.294L15.293 16.708L12 13.415L8.707 16.708L7.293 15.294L10.586 12.001L7.293 8.70801L8.707 7.29401L12 10.587L15.293 7.29401L16.707 8.70801L13.414 12.001L16.707 15.294Z" />
</svg>
</template>;