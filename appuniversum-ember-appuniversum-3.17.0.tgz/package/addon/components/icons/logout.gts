// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface LogoutIconSignature {
  Element: SVGSVGElement;
}

export const LogoutIcon: TOC<LogoutIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M10,0 L8,0 L8,10 L10,10 L10,0 Z M14.83,2.17 L13.41,3.59 C14.99,4.86 16,6.81 16,9 C16,12.87 12.87,16 9,16 C5.13,16 2,12.87 2,9 C2,6.81 3.01,4.86 4.58,3.58 L3.17,2.17 C1.23,3.82 0,6.26 0,9 C0,13.97 4.03,18 9,18 C13.97,18 18,13.97 18,9 C18,6.26 16.77,3.82 14.83,2.17 Z" transform="translate(3 3)"/></svg></template>;