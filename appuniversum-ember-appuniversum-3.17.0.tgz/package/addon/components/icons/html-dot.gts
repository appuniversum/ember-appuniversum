// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface HtmlDotIconSignature {
  Element: SVGSVGElement;
}

export const HtmlDotIcon: TOC<HtmlDotIconSignature> = <template><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" ...attributes><path d="M8.207 4.293a1 1 0 0 1 0 1.414L3.914 10l4.293 4.293a1 1 0 1 1-1.414 1.414l-5-5a1 1 0 0 1 0-1.414l5-5a1 1 0 0 1 1.414 0Zm4.086 11.414a1 1 0 0 1 0-1.414L16.586 10l-4.293-4.293a1 1 0 0 1 1.414-1.414l5 5a1 1 0 0 1 0 1.414l-5 5a1 1 0 0 1-1.414 0Z"/><circle cx="21.5" cy="19" r="1"/></svg>
</template>;