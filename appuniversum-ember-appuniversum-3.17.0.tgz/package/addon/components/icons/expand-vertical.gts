// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ExpandVerticalIconSignature {
  Element: SVGSVGElement;
}

export const ExpandVerticalIcon: TOC<ExpandVerticalIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="15.29003 7.71002 16.70003 6.30002 12.00003 1.59002 7.28997 6.29002 8.70997 7.71002 11.00003 5.41002 11.00003 18.58998 8.70997 16.28998 7.28997 17.70998 12.00003 22.40998 16.71003 17.69998 15.30003 16.28998 13.00003 18.58998 13.00003 5.41002"/></svg></template>;