// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface LoginIconSignature {
  Element: SVGSVGElement;
}

export const LoginIcon: TOC<LoginIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12,4 C13.6477,4 15,5.35228 15,7 L15,10 L9,10 L9,7 C9,5.35228 10.3523,4 12,4 Z M17,10 L17,7 C17,4.24772 14.7523,2 12,2 C9.24771,2 7,4.24772 7,7 L7,10 L6,10 C4.89543,10 4,10.8954 4,12 L4,20 C4,21.1046 4.89543,22 6,22 L18,22 C19.1046,22 20,21.1046 20,20 L20,12 C20,10.8954 19.1046,10 18,10 L17,10 Z M6,12 L18,12 L18,20 L6,20 L6,12 Z"/></svg></template>;