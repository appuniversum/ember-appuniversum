// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface DocumentsIconSignature {
  Element: SVGSVGElement;
}

export const DocumentsIcon: TOC<DocumentsIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12.125,3 L17,8.1 L17,18.3 C17,19.2393 16.2728,20 15.375,20 L15.375,20 L4.99188,20 C4.09406,20 3.375,19.2393 3.375,18.3 L3.375,18.3 L3.38313,4.7 C3.38313,3.76075 4.10219,3 5,3 L5,3 L12.125,3 Z M12,0 L12,1.81818 L1.78947,1.81818 L1.78947,14.5455 L0,14.5455 L0,1.81818 C0,0.81364 0.80079,0 1.78947,0 L1.78947,0 L12,0 Z M11.3125,4.275 L11.3125,8.95 L15.7813,8.95 L11.3125,4.275 Z" transform="translate(3.5 2)"/></svg></template>;