// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface UploadIconSignature {
  Element: SVGSVGElement;
}

export const UploadIcon: TOC<UploadIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M13,22 L11,22 L11,9.92 L8.71,12.12 L7.3,10.76 L12,6.24 L16.71,10.76 L15.3,12.12 L13,9.92 L13,22 Z M22,4 L2,4 L2,2 L22,2 L22,4 Z"/></svg></template>;