// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface IndentIconSignature {
  Element: SVGSVGElement;
}

export const IndentIcon: TOC<IndentIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M11,2 L13,2 L13,22 L11,22 L11,2 Z M5.293,9.708 L6.586,11 L2,11 L2,13 L6.586,13 L5.293,14.294 L6.707,15.708 L10.414,12 L6.707,8.294 L5.293,9.708 Z M22,3 L14,3 L14,5 L22,5 L22,3 Z M14,7 L20,7 L20,9 L14,9 L14,7 Z M22,11 L14,11 L14,13 L22,13 L22,11 Z M14,15 L20,15 L20,17 L14,17 L14,15 Z M22,19 L14,19 L14,21 L22,21 L22,19 Z" fill-rule="evenodd"/></svg>
</template>;