// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ArrowRightIconSignature {
  Element: SVGSVGElement;
}

export const ArrowRightIcon: TOC<ArrowRightIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="13.88 7.99 16.17 5.7 0 5.7 0 3.7 16.17 3.7 13.88 1.41 15.29 0 20 4.7 15.29 9.41" transform="translate(2 7.295)"/></svg></template>;