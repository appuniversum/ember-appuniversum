// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CrossIconSignature {
  Element: SVGSVGElement;
}

export const CrossIcon: TOC<CrossIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="12.000015 13.414215 6.707095 18.707115 5.292885 17.292915 10.585815 12.000015 5.292885 6.707095 6.707095 5.292885 12.000015 10.585815 17.292915 5.292885 18.707115 6.707095 13.414215 12.000015 18.707115 17.292915 17.292915 18.707115"/></svg></template>;