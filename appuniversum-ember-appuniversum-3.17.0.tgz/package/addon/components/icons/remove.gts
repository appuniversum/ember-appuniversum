// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface RemoveIconSignature {
  Element: SVGSVGElement;
}

export const RemoveIcon: TOC<RemoveIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="21 11 3 11 3 13 21 13"/></svg></template>;