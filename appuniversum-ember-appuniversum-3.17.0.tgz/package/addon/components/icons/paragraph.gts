// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ParagraphIconSignature {
  Element: SVGSVGElement;
}

export const ParagraphIcon: TOC<ParagraphIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M9 2H21V4H18V22H16V4H13V22H11V14H9C5.691 14 3 11.309 3 8C3 4.691 5.691 2 9 2ZM9 12H11V4H9C6.794 4 5 5.794 5 8C5 10.206 6.794 12 9 12Z" />
</svg>
</template>;