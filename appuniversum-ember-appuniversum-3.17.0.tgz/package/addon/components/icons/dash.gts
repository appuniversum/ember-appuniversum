// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface DashIconSignature {
  Element: SVGSVGElement;
}

export const DashIcon: TOC<DashIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="3 13 3 11 21 11 21 13"/></svg></template>;