// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ArrowLeftIconSignature {
  Element: SVGSVGElement;
}

export const ArrowLeftIcon: TOC<ArrowLeftIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="6.11 8 4.69 9.41 0 4.69 4.69 0 6.11 1.41 3.81 3.69 20 3.69 20 5.69 3.81 5.69" transform="translate(2 7.295)"/></svg></template>;