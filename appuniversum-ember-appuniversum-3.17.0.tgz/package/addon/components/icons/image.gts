// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ImageIconSignature {
  Element: SVGSVGElement;
}

export const ImageIcon: TOC<ImageIconSignature> = <template><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" ...attributes><path d="M4 21.001h16a1 1 0 0 0 1-1v-16a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1Zm15-2H5v-14h14v14Zm-5-8-2.588 3.882L10 13.001l-3 4h10l-3-6Zm-3.586-.586a2 2 0 1 0-2.828-2.828 2 2 0 0 0 2.828 2.828Z" clip-rule="evenodd"/></svg>
</template>;