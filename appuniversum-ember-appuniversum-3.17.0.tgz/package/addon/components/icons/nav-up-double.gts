// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface NavUpDoubleIconSignature {
  Element: SVGSVGElement;
}

export const NavUpDoubleIcon: TOC<NavUpDoubleIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M8.4,2.8 L15.4,9.8 L16.8,8.4 L8.4,0 L0,8.4 L1.4,9.8 L8.4,2.8 Z M8.4,7.8 L15.4,14.8 L16.8,13.4 L8.4,5 L0,13.4 L1.4,14.8 L8.4,7.8 Z" transform="translate(3.6 4.6)" fill-rule="evenodd"/></svg></template>;