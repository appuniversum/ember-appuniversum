// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CaretUpDownIconSignature {
  Element: SVGSVGElement;
}

export const CaretUpDownIcon: TOC<CaretUpDownIconSignature> = <template><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" ...attributes><path d="m17 14-5 6-5-6zM7 10l5-6 5 6z"/></svg>
</template>;