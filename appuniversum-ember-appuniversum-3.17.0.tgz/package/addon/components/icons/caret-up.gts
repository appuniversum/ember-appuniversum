// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CaretUpIconSignature {
  Element: SVGSVGElement;
}

export const CaretUpIcon: TOC<CaretUpIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="7 15 12 9 17 15"/></svg></template>;