// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface NavUpIconSignature {
  Element: SVGSVGElement;
}

export const NavUpIcon: TOC<NavUpIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="19 16.9 12 9.9 5 16.9 3.6 15.5 12 7.1 20.4 15.5"/></svg></template>;