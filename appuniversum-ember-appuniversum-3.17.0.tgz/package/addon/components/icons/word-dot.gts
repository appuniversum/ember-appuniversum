// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface WordDotIconSignature {
  Element: SVGSVGElement;
}

export const WordDotIcon: TOC<WordDotIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M5.60038,4 L6.69638,11.6047 L9.9547,4 L13.0453,4 L14.1511,11.6047 L17.3996,4 L20.5,4 L14.9312,17 L11.8406,17 L10.7348,9.4052 L7.48629,17 L4.39578,17 L2.5,4 L5.60038,4 Z"/></svg></template>;