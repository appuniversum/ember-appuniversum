// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface FolderIconSignature {
  Element: SVGSVGElement;
}

export const FolderIcon: TOC<FolderIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M2,6 C2,4.89543 2.89543,4 4,4 L9,4 C9.26522,4 9.51957,4.10536 9.70711,4.29289 L11.4142,6 L20,6 C21.1046,6 22,6.89543 22,8 L22,18 C22,19.1046 21.1046,20 20,20 L4,20 C2.89543,20 2,19.1046 2,18 L2,6 Z M8.58579,6 L4,6 L4,18 L20,18 L20,8 L11,8 C10.7348,8 10.4804,7.89464 10.2929,7.70711 L8.58579,6 Z"/></svg></template>;