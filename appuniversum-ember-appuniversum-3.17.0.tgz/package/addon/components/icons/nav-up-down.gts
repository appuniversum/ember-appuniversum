// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface NavUpDownIconSignature {
  Element: SVGSVGElement;
}

export const NavUpDownIcon: TOC<NavUpDownIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M19,13.2 L20.4,14.59999 L12,23 L3.6,14.59999 L5,13.2 L12,20.2 L19,13.2 Z M12,1 L20.4,9.4 L19,10.8 L12,3.8 L5,10.8 L3.6,9.4 L12,1 Z"/></svg></template>;