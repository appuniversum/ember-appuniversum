// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface BinIconSignature {
  Element: SVGSVGElement;
}

export const BinIcon: TOC<BinIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M5,19.5 C5,20.0304 5.21071,20.5391 5.58579,20.9142 C5.96086,21.2893 6.46957,21.5 7,21.5 L17,21.5 C17.5304,21.5 18.0391,21.2893 18.4142,20.9142 C18.7893,20.5391 19,20.0304 19,19.5 L19,7.5 L5,7.5 L5,19.5 Z M7,9.5 L17,9.5 L17,19.5 L7,19.5 L7,9.5 Z M15,4.5 L21,4.5 L21,6.5 L3,6.5 L3,4.5 L9,4.5 L9,2.5 L15,2.5 L15,4.5 Z M9,11.5 L9,17.5 L11,17.5 L11,11.5 L9,11.5 Z M13,11.5 L13,17.5 L15,17.5 L15,11.5 L13,11.5 Z"/></svg></template>;