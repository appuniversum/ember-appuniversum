// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface OrderedListIconSignature {
  Element: SVGSVGElement;
}

export const OrderedListIcon: TOC<OrderedListIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M1.5,17.625 L3.71,17.625 L3.71,18.188 L2.606,18.188 L2.606,19.313 L3.712,19.313 L3.712,19.875 L1.5,19.875 L1.5,21 L4.816,21 L4.816,16.5 L1.5,16.5 L1.5,17.625 Z M2.605,7.5 L3.711,7.5 L3.711,3 L1.5,3 L1.5,4.125 L2.605,4.125 L2.605,7.5 Z M1.5,10.875 L3.49,10.875 L1.5,13.238 L1.5,14.25 L4.816,14.25 L4.816,13.125 L2.826,13.125 L4.816,10.762 L4.816,9.75 L1.5,9.75 L1.5,10.875 Z M7.026,4.125 L7.026,6.375 L22.5,6.375 L22.5,4.125 L7.026,4.125 Z M7.026,19.875 L22.5,19.875 L22.5,17.625 L7.026,17.625 L7.026,19.875 Z M7.026,13.125 L22.5,13.125 L22.5,10.875 L7.026,10.875 L7.026,13.125 Z"/></svg></template>;