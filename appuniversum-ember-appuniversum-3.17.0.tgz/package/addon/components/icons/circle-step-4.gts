// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CircleStep4IconSignature {
  Element: SVGSVGElement;
}

export const CircleStep4Icon: TOC<CircleStep4IconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12,2 C17.5228,2 22,6.47715 22,12 C22,17.5228 17.5228,22 12,22 C6.47715,22 2,17.5228 2,12 C2,6.47715 6.47715,2 12,2 Z M12,4 C7.58172,4 4,7.58172 4,12 C4,15.3988973 6.11961659,18.3027053 9.10911981,19.4617213 L12,13 L12,4 Z"/></svg></template>;