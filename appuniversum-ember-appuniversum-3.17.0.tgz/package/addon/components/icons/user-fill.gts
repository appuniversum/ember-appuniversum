// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface UserFillIconSignature {
  Element: SVGSVGElement;
}

export const UserFillIcon: TOC<UserFillIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M6,8 C6,4.68629 8.68629,2 12,2 C15.3137,2 18,4.68629 18,8 C18,11.3137 15.3137,14 12,14 C8.68629,14 6,11.3137 6,8 Z M4,22 C3.44772,22 3,21.5523 3,21 C3,18.2386 5.23858,16 8,16 L16,16 C18.7614,16 21,18.2386 21,21 C21,21.5523 20.5523,22 20,22 C19.4477,22 4.55228,22 4,22 Z"/></svg></template>;