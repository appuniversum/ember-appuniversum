// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface SwitchIconSignature {
  Element: SVGSVGElement;
}

export const SwitchIcon: TOC<SwitchIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M7.11,15 L5.69,16.41 L1,11.69 L5.69,7 L7.11,8.41 L4.81,10.69 L19.16,10.689 L16.88,8.41 L18.29,7 L23,11.7 L18.29,16.41 L16.88,14.99 L19.17,12.7 L4.819,12.699 L7.11,15 Z"/></svg></template>;