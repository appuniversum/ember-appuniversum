// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ReverseIndentIconSignature {
  Element: SVGSVGElement;
}

export const ReverseIndentIcon: TOC<ReverseIndentIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M11,2 L13,2 L13,22 L11,22 L11,2 Z M22,11 L17.414,11 L18.707,9.708 L17.293,8.294 L13.586,12 L17.293,15.708 L18.707,14.294 L17.414,13 L22,13 L22,11 Z M10,3 L2,3 L2,5 L10,5 L10,3 Z M4,7 L10,7 L10,9 L4,9 L4,7 Z M10,11 L2,11 L2,13 L10,13 L10,11 Z M4,15 L10,15 L10,17 L4,17 L4,15 Z M10,19 L2,19 L2,21 L10,21 L10,19 Z" fill-rule="evenodd"/></svg>
</template>;