// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CaretDownIconSignature {
  Element: SVGSVGElement;
}

export const CaretDownIcon: TOC<CaretDownIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="17 9 12 15 7 9"/></svg></template>;