// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface MessageIconSignature {
  Element: SVGSVGElement;
}

export const MessageIcon: TOC<MessageIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M8,16 C8.53043,16 9.03914,16.2107 9.41421,16.5858 L12,19.1716 L14.5858,16.5858 C14.9609,16.2107 15.4696,16 16,16 L21,16 L21,4 L3,4 L3,16 L8,16 Z M12,22 L8,18 L3,18 C1.89543,18 1,17.1046 1,16 L1,4 C1,2.89543 1.89543,2 3,2 L21,2 C22.1046,2 23,2.89543 23,4 L23,16 C23,17.1046 22.1046,18 21,18 L16,18 L12,22 Z M6,11 L18,11 L18,13 L6,13 L6,11 Z M18,7 L6,7 L6,9 L18,9 L18,7 Z"/></svg></template>;