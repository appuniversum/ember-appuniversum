// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ArrowDownIconSignature {
  Element: SVGSVGElement;
}

export const ArrowDownIcon: TOC<ArrowDownIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="8 13.91 5.71 16.2 5.71 0 3.71 0 3.71 16.2 1.42 13.91 8.8817842e-16 15.32 4.71 20 9.42 15.29 8 13.91" transform="translate(7.29 2)"/></svg></template>;