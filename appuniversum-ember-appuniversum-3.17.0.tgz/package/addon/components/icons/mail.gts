// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface MailIconSignature {
  Element: SVGSVGElement;
}

export const MailIcon: TOC<MailIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M10.5,10.6611 L1.5,2.3958 L1.5,13.5 L19.5,13.5 L19.5,2.3958 L10.5,10.6611 Z M21,15 L0,15 L0,0 L21,0 L21,15 Z M18.2579,1.5 L2.74214,1.5 L10.5,8.6246 L18.2579,1.5 Z" transform="translate(1.5 4.5)" fill-rule="evenodd"/></svg></template>;