// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CheckboxCheckedIconSignature {
  Element: SVGSVGElement;
}

export const CheckboxCheckedIcon: TOC<CheckboxCheckedIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M19,3 L5,3 C3.895,3 3,3.895 3,5 L3,19 C3,20.105 3.895,21 5,21 L19,21 C20.105,21 21,20.105 21,19 L21,5 C21,3.895 20.105,3 19,3 Z M10,17 L5,12 L6.415,10.585 L10,14.17 L17.585,6.585 L19,8 L10,17 Z"/></svg></template>;