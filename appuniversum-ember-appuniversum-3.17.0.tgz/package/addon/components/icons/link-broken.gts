// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface LinkBrokenIconSignature {
  Element: SVGSVGElement;
}

export const LinkBrokenIcon: TOC<LinkBrokenIconSignature> = <template><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" ...attributes><path d="M16.24 3.51a3 3 0 0 0-4.24 0L8.47 7.05l1.41 1.41 3.53-3.54a1 1 0 0 1 1.41 0l1.42-1.41Zm2.83 5.66a1 1 0 0 1 0 1.41l-3.54 3.54 1.41 1.41L20.48 12a3 3 0 0 0 0-4.24l-1.41 1.41ZM3.52 16.24l1.41-1.41a1 1 0 0 1 0-1.41l3.53-3.54-1.41-1.42L3.52 12a3 3 0 0 0 0 4.24Zm10.6-.7-3.54 3.54a1 1 0 0 1-1.41 0l-1.41 1.41a3 3 0 0 0 4.24 0L15.54 17l-1.42-1.46ZM19.78 2.81l1.41 1.41-7.07 7.07-1.41-1.41zM9.88 12.71l1.41 1.41-7.07 7.07-1.41-1.41zM19.78 14.54h2.83v2h-2.83zM14.54 19.78h2v2.83h-2zM7.46 1.39h2v2.83h-2zM1.39 7.46h2.83v2H1.39z"/></svg>
</template>;