// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface UsersSingleIconSignature {
  Element: SVGSVGElement;
}

export const UsersSingleIcon: TOC<UsersSingleIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M12.0804,15.5 C15.0723,15.5 17.8838,16.6787 20,18.8199 L18.4733,20.3645 C16.7652,18.6363 14.4957,17.6848 12.0804,17.6848 C9.59606,17.6848 7.27903,18.6844 5.55692,20.5 L4,18.987 C6.1324,16.7388 9.00223,15.5 12.0804,15.5 Z M12,3.5 C14.7571,3.5 17,5.74291 17,8.5 C17,11.2571 14.7571,13.5 12,13.5 C9.24291,13.5 7,11.2571 7,8.5 C7,5.74291 9.24291,3.5 12,3.5 Z M12,5.5 C10.3459,5.5 9,6.84594 9,8.5 C9,10.1541 10.3459,11.5 12,11.5 C13.6541,11.5 15,10.1541 15,8.5 C15,6.84594 13.6541,5.5 12,5.5 Z" fill-rule="evenodd"/></svg>
</template>;