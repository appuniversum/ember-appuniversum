// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface UnorderedListIconSignature {
  Element: SVGSVGElement;
}

export const UnorderedListIcon: TOC<UnorderedListIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M3.622,10.4 C2.724,10.4 2,11.115 2,12 C2,12.885 2.724,13.6 3.622,13.6 C4.519,13.6 5.243,12.885 5.243,12 C5.243,11.115 4.519,10.4 3.622,10.4 Z M3.622,4 C2.724,4 2,4.715 2,5.6 C2,6.485 2.724,7.2 3.622,7.2 C4.519,7.2 5.243,6.485 5.243,5.6 C5.243,4.715 4.519,4 3.622,4 Z M3.622,16.8 C2.719,16.8 2,17.52 2,18.4 C2,19.28 2.73,20 3.622,20 C4.514,20 5.243,19.28 5.243,18.4 C5.243,17.52 4.524,16.8 3.622,16.8 L3.622,16.8 Z M6.865,19.467 L22,19.467 L22,17.333 L6.865,17.333 L6.865,19.467 Z M6.865,13.067 L22,13.067 L22,10.933 L6.865,10.933 L6.865,13.067 Z M6.865,4.533 L6.865,6.667 L22,6.667 L22,4.533 L6.865,4.533 L6.865,4.533 Z"/></svg>
</template>;