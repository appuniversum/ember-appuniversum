// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface AlignCenterIconSignature {
  Element: SVGSVGElement;
}

export const AlignCenterIcon: TOC<AlignCenterIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M3 3H21V5H3V3ZM5 7H19V9H5V7ZM22 11H2V13H22V11ZM5 15H19V17H5V15ZM21 19H3V21H21V19Z" />
</svg>
</template>;