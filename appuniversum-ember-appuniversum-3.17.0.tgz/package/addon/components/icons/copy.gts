// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface CopyIconSignature {
  Element: SVGSVGElement;
}

export const CopyIcon: TOC<CopyIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><path d="M2,4 C2,2.89543 2.89543,2 4,2 L14,2 C15.1046,2 16,2.89543 16,4 L16,8 L20,8 C21.1046,8 22,8.89543 22,10 L22,20 C22,21.1046 21.1046,22 20,22 L10,22 C8.89543,22 8,21.1046 8,20 L8,16 L4,16 C2.89543,16 2,15.1046 2,14 L2,4 Z M10,16 L10,20 L20,20 L20,10 L16,10 L16,14 C16,15.1046 15.1046,16 14,16 L10,16 Z M14,14 L14,4 L4,4 L4,14 L14,14 Z"/></svg></template>;