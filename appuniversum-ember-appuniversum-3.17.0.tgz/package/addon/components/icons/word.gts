// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface WordIconSignature {
  Element: SVGSVGElement;
}

export const WordIcon: TOC<WordIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="7.98629 18.5 4.89578 18.5 3 5.5 6.10038 5.5 7.19638 13.1047 10.4547 5.5 13.5453 5.5 14.6511 13.1047 17.8996 5.5 21 5.5 15.4312 18.5 12.3406 18.5 11.2348 10.9052"/></svg></template>;