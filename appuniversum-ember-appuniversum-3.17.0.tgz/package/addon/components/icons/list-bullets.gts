// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ListBulletsIconSignature {
  Element: SVGSVGElement;
}

export const ListBulletsIcon: TOC<ListBulletsIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes>
<path fill-rule="evenodd" clip-rule="evenodd" d="M7 2H3C2.448 2 2 2.448 2 3V7C2 7.552 2.448 8 3 8H7C7.553 8 8 7.552 8 7V3C8 2.448 7.553 2 7 2ZM7 9H3C2.448 9 2 9.448 2 10V14C2 14.552 2.448 15 3 15H7C7.553 15 8 14.552 8 14V10C8 9.448 7.553 9 7 9ZM3 16H7C7.553 16 8 16.448 8 17V21C8 21.552 7.553 22 7 22H3C2.448 22 2 21.552 2 21V17C2 16.448 2.448 16 3 16ZM6 6H4V4H6V6ZM4 13H6V11H4V13ZM6 20H4V18H6V20ZM22 4H10V6H22V4ZM10 11H22V13H10V11ZM22 18H10V20H22V18Z"/>
</svg>
</template>;