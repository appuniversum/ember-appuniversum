// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ArrowUpIconSignature {
  Element: SVGSVGElement;
}

export const ArrowUpIcon: TOC<ArrowUpIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="8 6.12 5.71 3.83 5.71 20 3.71 20 3.71 3.83 1.42 6.12 0 4.71 4.71 0 9.42 4.71" transform="translate(7.29 2)"/></svg></template>;