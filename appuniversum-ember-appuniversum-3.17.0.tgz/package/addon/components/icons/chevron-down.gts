// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface ChevronDownIconSignature {
  Element: SVGSVGElement;
}

export const ChevronDownIcon: TOC<ChevronDownIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="12 16.9 3.6 8.49999 5 7.1 12 14.1 19 7.1 20.4 8.49999"/></svg></template>;