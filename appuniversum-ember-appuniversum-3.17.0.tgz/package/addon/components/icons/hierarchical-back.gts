// THIS FILE IS GENERATED. ANY CHANGES TO THIS FILE WILL BE LOST.
import type { TOC } from '@ember/component/template-only';

export interface HierarchicalBackIconSignature {
  Element: SVGSVGElement;
}

export const HierarchicalBackIcon: TOC<HierarchicalBackIconSignature> = <template><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ...attributes><polygon points="13.4693 8.68077 12.0469 10.10325 9.7403 7.79669 9.7403 18.04215 19.9999 18.04215 19.9999 20.05385 7.72862 20.05385 7.72862 7.79721 5.42258 10.10325 4.0001 8.68077 8.73472 3.94615"/></svg></template>;