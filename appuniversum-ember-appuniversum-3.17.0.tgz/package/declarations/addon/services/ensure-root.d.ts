export declare function ensureRoot(node: Node): HTMLElement;
//# sourceMappingURL=ensure-root.d.ts.map