import Service from '@ember/service';
export default class ModalContainerService extends Service {
    element: HTMLElement | null;
    setElement: (element: HTMLElement) => void;
}
declare module '@ember/service' {
    interface Registry {
        'modal-container': ModalContainerService;
    }
}
//# sourceMappingURL=modal-container.d.ts.map