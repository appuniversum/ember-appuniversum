interface Args {
    options: object;
}
declare const _default: import("ember-modifier").FunctionBasedModifier<{
    Args: {
        Positional: unknown[];
        Named: Args;
    };
    Element: HTMLElement;
}>;
export default _default;
//# sourceMappingURL=au-inputmask.d.ts.map