import type Owner from '@ember/owner';
import Modifier, { type ArgsFor } from 'ember-modifier';
export interface AuDateInputModifierSignature {
    Args: {
        Named: {
            value?: string | Date;
            prefillYear?: boolean;
            onChange?: (isoDate: string | null, date: Date | null) => void;
        };
    };
    Element: HTMLInputElement;
}
type Signature = AuDateInputModifierSignature;
export default class AuDateInputModifier extends Modifier<Signature> {
    input: Signature['Element'];
    argValue?: Signature['Args']['Named']['value'];
    argOnChange?: Signature['Args']['Named']['onChange'];
    currentIsoDate?: string | null;
    constructor(owner: Owner, args: ArgsFor<Signature>);
    get isInitialized(): boolean;
    modify(input: Signature['Element'], _positional: never, { value, onChange, prefillYear }: Signature['Args']['Named']): void;
    initialize(input: Signature['Element'], prefillYear?: boolean): void;
    onChange(isoDate: string | null, date: Date | null): void;
    removeInputmask: () => void;
}
export {};
//# sourceMappingURL=au-date-input.d.ts.map