import type { TOC } from '@ember/component/template-only';
interface Signature {
    Element: HTMLDivElement;
}
export declare const LoadingAnimation: TOC<Signature>;
export {};
//# sourceMappingURL=loading-animation.d.ts.map