import Component from '@glimmer/component';
import { type AuContentSignature } from '../../components/au-content';
export interface MaybeAuContentSignature {
    Args: {
        useAuContent: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: AuContentSignature['Element'];
}
export declare class MaybeAuContent extends Component<MaybeAuContentSignature> {
    constructor(owner: unknown, args: MaybeAuContentSignature['Args']);
    get useAuContent(): boolean;
}
//# sourceMappingURL=maybe-au-content.d.ts.map