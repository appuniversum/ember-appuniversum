type FloatingUiElement = HTMLElement | string;
type PositionalArgs = [FloatingUiElement] | [FloatingUiElement, FloatingUiElement];
interface NamedArgs {
    defaultPlacement?: 'top' | 'right' | 'bottom' | 'bottom-start' | 'bottom-end' | 'left';
    options?: {
        arrow?: {
            offset?: number;
            padding?: number;
            position?: string | number;
        };
        floater?: {
            offset?: number;
        };
        shift?: {
            padding?: number;
        };
    };
}
declare const _default: import("ember-modifier").FunctionBasedModifier<{
    Args: {
        Positional: PositionalArgs;
        Named: NamedArgs;
    };
    Element: HTMLElement;
}>;
export default _default;
//# sourceMappingURL=floating-ui.d.ts.map