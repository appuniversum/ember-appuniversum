/**
 * A very basic alternative to https://github.com/JedWatson/classnames
 */
export declare function cn(...classNames: Array<string | undefined>): string;
//# sourceMappingURL=class-names.d.ts.map