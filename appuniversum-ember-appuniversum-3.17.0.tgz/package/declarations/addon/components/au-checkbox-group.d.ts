import AuCheckbox from './au-checkbox';
import Component from '@glimmer/component';
import type { WithBoundArgs } from '@glint/template';
export interface AuCheckboxGroupSignature {
    Args: {
        alignment?: 'inline';
        name?: string;
        selected?: string[];
        disabled?: boolean;
        onChange?: (updatedGroupValue: string[], event: Event) => void;
    };
    Blocks: {
        default: [
            {
                Checkbox: WithBoundArgs<typeof AuCheckbox, 'name' | 'inGroup' | 'groupValue' | 'disabled' | 'onChangeGroup'>;
            }
        ];
    };
    Element: HTMLDivElement;
}
export default class AuCheckboxGroup extends Component<AuCheckboxGroupSignature> {
    get alignmentClass(): "" | "au-c-control-group--inline";
}
//# sourceMappingURL=au-checkbox-group.d.ts.map