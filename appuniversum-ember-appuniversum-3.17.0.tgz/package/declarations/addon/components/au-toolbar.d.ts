import type { TOC } from '@ember/component/template-only';
import Component from '@glimmer/component';
export interface AuToolbarSignature {
    Args: {
        reverse?: boolean;
        border?: 'top' | 'bottom';
        skin?: 'tint';
        size?: 'small' | 'medium' | 'large';
        nowrap?: boolean;
    };
    Blocks: {
        default: [typeof Group];
    };
    Element: HTMLDivElement;
}
export default class AuToolbar extends Component<AuToolbarSignature> {
    get reverse(): "" | "au-c-toolbar--reverse";
    get border(): "" | "au-c-toolbar--top" | "au-c-toolbar--bottom";
    get skin(): "" | "au-c-toolbar--tint";
    get size(): "" | "au-c-toolbar--small" | "au-c-toolbar--medium" | "au-c-toolbar--large";
    get nowrap(): "" | "au-c-toolbar--nowrap";
}
interface GroupSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
declare const Group: TOC<GroupSignature>;
export {};
//# sourceMappingURL=au-toolbar.d.ts.map