import Component from '@glimmer/component';
export interface AuTextareaSignature {
    Args: {
        disabled?: boolean;
        error?: boolean;
        warning?: boolean;
        width?: 'block';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLTextAreaElement;
}
export default class AuTextarea extends Component<AuTextareaSignature> {
    get width(): "" | "au-c-textarea--block";
    get error(): "" | "au-c-textarea--error";
    get warning(): "" | "au-c-textarea--warning";
    get disabled(): "" | "is-disabled";
}
//# sourceMappingURL=au-textarea.d.ts.map