import Component from '@glimmer/component';
export interface AuCheckboxSignature {
    Args: {
        checked?: boolean;
        disabled?: boolean;
        groupValue?: string[];
        indeterminate?: boolean;
        inGroup?: boolean;
        name?: string;
        onChange?: (checked: boolean, event: Event) => void;
        onChangeGroup?: (newValue: string[], event: Event) => void;
        value?: string;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLInputElement;
}
export default class AuCheckbox extends Component<AuCheckboxSignature> {
    get groupValue(): string[];
    get isCheckedInGroup(): boolean;
    get checked(): boolean | undefined;
    onChange(event: Event): void;
}
//# sourceMappingURL=au-checkbox.d.ts.map