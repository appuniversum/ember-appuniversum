import type { TOC } from '@ember/component/template-only';
export interface AuPanelSignature {
    Args: {
        active?: boolean;
    };
    Blocks: {
        default: [typeof Section];
    };
    Element: HTMLDivElement;
}
declare const AuPanel: TOC<AuPanelSignature>;
export default AuPanel;
interface SectionSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
declare const Section: TOC<SectionSignature>;
//# sourceMappingURL=au-panel.d.ts.map