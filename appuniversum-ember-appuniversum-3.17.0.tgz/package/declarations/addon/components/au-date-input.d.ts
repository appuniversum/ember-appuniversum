import Component from '@glimmer/component';
import { type AuInputSignature } from './au-input';
import { type AuDateInputModifierSignature } from '../modifiers/au-date-input';
export interface AuDateInputSignature {
    Args: {
        disabled?: AuInputSignature['Args']['disabled'];
        error?: AuInputSignature['Args']['error'];
        warning?: AuInputSignature['Args']['warning'];
        width?: AuInputSignature['Args']['width'];
        value?: AuDateInputModifierSignature['Args']['Named']['value'];
        prefillYear?: AuDateInputModifierSignature['Args']['Named']['prefillYear'];
        onChange?: AuDateInputModifierSignature['Args']['Named']['onChange'];
    };
    Element: AuInputSignature['Element'];
}
export default class AuDateInput extends Component<AuDateInputSignature> {
}
//# sourceMappingURL=au-date-input.d.ts.map