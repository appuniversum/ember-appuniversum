import Component from '@glimmer/component';
export interface AuAppSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuApp extends Component<AuAppSignature> {
}
//# sourceMappingURL=au-app.d.ts.map