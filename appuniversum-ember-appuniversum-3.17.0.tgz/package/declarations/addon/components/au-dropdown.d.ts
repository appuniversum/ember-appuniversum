import Component from '@glimmer/component';
import type { AuButtonSignature } from './au-button';
export interface AuDropdownSignature {
    Args: {
        alignment?: 'left' | 'right';
        alert?: boolean;
        hideText?: boolean;
        icon?: AuButtonSignature['Args']['icon'];
        iconAlignment?: AuButtonSignature['Args']['iconAlignment'];
        onClose?: () => unknown;
        size?: AuButtonSignature['Args']['size'];
        skin?: AuButtonSignature['Args']['skin'];
        title?: string;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuDropdown extends Component<AuDropdownSignature> {
    referenceElement: HTMLElement;
    arrowElement: HTMLElement;
    dropdownOpen: boolean;
    reference: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
    get docRoot(): HTMLElement;
    arrow: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
    openDropdown(): void;
    closeDropdown(): void;
    toggleDropdown(): void;
    clickOutsideDeactivates(event: Event): boolean;
    get alignment(): "bottom" | "bottom-start" | "bottom-end";
    get skin(): "link" | "primary" | "secondary" | "naked" | "link-secondary" | "link-bold";
    get icon(): string | import("@glint/template").ComponentLike<{
        Element: Element;
    }> | import("@ember/component/template-only").TOC<import("./icons/chevron-down").ChevronDownIconSignature>;
    get iconAlignment(): "left" | "right";
}
//# sourceMappingURL=au-dropdown.d.ts.map