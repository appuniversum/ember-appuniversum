import Component from '@glimmer/component';
import type { ComponentLike } from '@glint/template';
export interface AuIconSignature {
    Args: {
        alignment?: 'left' | 'right';
        ariaHidden?: boolean | 'true' | 'false';
        icon: string | ComponentLike<{
            Element: Element;
        }>;
        size?: 'large';
    };
    Element: Element;
}
export default class AuIcon extends Component<AuIconSignature> {
    get iconPrefix(): string;
    get size(): "au-c-icon--large" | "";
    get alignment(): "" | "au-c-icon--left" | "au-c-icon--right";
    get ariaHidden(): "true" | "false";
    get iconComponent(): false | ComponentLike<{
        Element: Element;
    }>;
}
//# sourceMappingURL=au-icon.d.ts.map