import Component from '@glimmer/component';
import type ModalContainerService from '../services/modal-container';
export interface AuModalContainerSignature {
    Element: HTMLDivElement;
}
export default class AuModalContainer extends Component<AuModalContainerSignature> {
    modalContainer: ModalContainerService;
    registerModalContainer: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
}
//# sourceMappingURL=au-modal-container.d.ts.map