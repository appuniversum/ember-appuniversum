import Component from '@glimmer/component';
export interface AuHeadingSignature {
    Args: {
        level?: '1' | '2' | '3' | '4' | '5' | '6';
        skin?: '1' | '2' | '3' | '4' | '5' | '6' | 'functional';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLHeadingElement;
}
export default class AuHeading extends Component<AuHeadingSignature> {
    get skin(): "au-c-heading--1" | "au-c-heading--2" | "au-c-heading--3" | "au-c-heading--4" | "au-c-heading--5" | "au-c-heading--6" | "au-c-heading--functional";
}
//# sourceMappingURL=au-heading.d.ts.map