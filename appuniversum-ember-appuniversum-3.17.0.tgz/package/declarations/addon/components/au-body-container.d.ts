import Component from '@glimmer/component';
export interface AuBodyContainerSignature {
    Args: {
        scroll?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuBodyContainer extends Component<AuBodyContainerSignature> {
    get scroll(): "" | "au-c-body-container--scroll";
}
//# sourceMappingURL=au-body-container.d.ts.map