import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuInputSignature {
    Args: {
        disabled?: boolean;
        error?: boolean;
        icon?: AuIconSignature['Args']['icon'];
        iconAlignment?: 'left' | 'right';
        warning?: boolean;
        width?: 'block';
    };
    Element: HTMLInputElement;
}
export default class AuInput extends Component<AuInputSignature> {
    get width(): "" | "au-c-input--block";
    get iconAlignment(): "left" | "right";
    get iconAlignmentClass(): "" | "au-c-input-wrapper--left" | "au-c-input-wrapper--right";
    get error(): "" | "au-c-input--error";
    get warning(): "" | "au-c-input--warning";
    get disabled(): "" | "is-disabled";
    get classes(): string;
}
//# sourceMappingURL=au-input.d.ts.map