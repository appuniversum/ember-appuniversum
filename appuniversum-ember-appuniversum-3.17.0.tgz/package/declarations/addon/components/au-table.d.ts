import Component from '@glimmer/component';
export interface AuTableSignature {
    Args: {
        size?: 'small';
    };
    Blocks: {
        body: [];
        footer: [];
        header: [];
        title: [];
    };
    Element: HTMLTableElement;
}
export default class AuTable extends Component<AuTableSignature> {
    get size(): "" | "au-c-table--small";
}
//# sourceMappingURL=au-table.d.ts.map