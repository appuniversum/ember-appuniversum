import Component from '@glimmer/component';
import type { WithBoundArgs } from '@glint/template';
import { type MaybeAuContentSignature } from '../private/components/maybe-au-content';
import { type AuIconSignature } from './au-icon';
export interface AuCardSignature {
    Args: {
        divided?: boolean;
        expandable?: boolean;
        flex?: boolean;
        isExpanded?: boolean;
        isOpenInitially?: boolean;
        manualControl?: boolean;
        openSection?: () => void;
        size?: 'small' | 'tiny' | 'flush';
        shadow?: boolean;
        standOut?: boolean;
        textCenter?: boolean;
        disableAuContent?: boolean;
    };
    Blocks: {
        default: [
            {
                header?: typeof Header;
                content?: WithBoundArgs<typeof Content, 'disableAuContent'>;
                footer?: WithBoundArgs<typeof Footer, 'disableAuContent'>;
            }
        ];
    };
    Element: HTMLElement;
}
export default class AuCard extends Component<AuCardSignature> {
    isExpanded: boolean;
    constructor(owner: unknown, args: AuCardSignature['Args']);
    get sectionOpen(): boolean | undefined;
    get size(): "" | "au-c-card--padding-small" | "au-c-card--padding-tiny" | "au-c-card--padding";
    get flex(): "" | "au-c-card--flex";
    get expandable(): "" | "au-c-card--expandable";
    get shadow(): "" | "au-c-card--shadow";
    get divided(): "" | "au-c-card--divided";
    get textCenter(): "" | "au-c-card--text-center";
    get standOut(): "" | "au-c-card--standout";
    openSection(): void;
}
interface HeaderSignature {
    Args: {
        badgeIcon?: AuIconSignature['Args']['icon'];
        badgeNumber?: number;
        badgeSize?: 'small';
        badgeSkin?: 'border' | 'action' | 'brand' | 'success' | 'warning' | 'error';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
declare class Header extends Component<HeaderSignature> {
    get badgeSkin(): "au-c-badge--border" | "au-c-badge--action" | "au-c-badge--brand" | "au-c-badge--success" | "au-c-badge--warning" | "au-c-badge--error" | "au-c-badge--default";
    get badgeSize(): "" | "au-c-badge--small";
}
interface ContentSignature {
    Args: {
        disableAuContent?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: MaybeAuContentSignature['Element'];
}
declare class Content extends Component<ContentSignature> {
}
interface FooterSignature {
    Args: {
        disableAuContent?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: MaybeAuContentSignature['Element'];
}
declare class Footer extends Component<FooterSignature> {
}
export {};
//# sourceMappingURL=au-card.d.ts.map