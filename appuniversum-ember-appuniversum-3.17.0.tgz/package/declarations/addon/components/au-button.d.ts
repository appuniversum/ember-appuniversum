import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
declare const SKINS: readonly ["primary", "secondary", "naked", "link", "link-secondary", "link-bold"];
export interface AuButtonSignature {
    Args: {
        alert?: boolean;
        disabled?: boolean;
        hideText?: boolean;
        icon?: AuIconSignature['Args']['icon'];
        iconAlignment?: 'left' | 'right';
        loading?: boolean;
        loadingMessage?: string;
        size?: 'large';
        skin?: (typeof SKINS)[number];
        width?: 'block';
        wrap?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLButtonElement;
}
export default class AuButton extends Component<AuButtonSignature> {
    get skin(): "link" | "primary" | "secondary" | "naked" | "link-secondary" | "link-bold";
    get isDisabled(): boolean | undefined;
    get sizeClass(): "" | "au-c-button--large";
    get widthClass(): "" | "au-c-button--block";
    get skinClass(): string;
    get alertClass(): "" | "au-c-button--alert";
    get disabledClass(): "" | "is-disabled";
    get loadingClass(): "" | "is-loading";
    get loadingMessage(): string;
    get isIconLeft(): boolean;
    get isIconRight(): boolean;
    get iconAlignment(): "left" | "right";
    get iconOnlyClass(): "" | "au-c-button--icon-only";
}
export {};
//# sourceMappingURL=au-button.d.ts.map