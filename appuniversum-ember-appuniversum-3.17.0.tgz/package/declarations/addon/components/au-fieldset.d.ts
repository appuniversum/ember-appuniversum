import type { TOC } from '@ember/component/template-only';
import Component from '@glimmer/component';
export interface AuFieldsetSignature {
    Args: {
        alignment?: 'inline';
    };
    Blocks: {
        default: [
            {
                legend?: typeof Legend;
                content?: typeof Content;
            }
        ];
    };
    Element: HTMLFieldSetElement;
}
export default class AuFieldset extends Component<AuFieldsetSignature> {
    get alignment(): "" | "au-c-fieldset--inline";
}
interface LegendSignature {
    Args: {
        error?: boolean;
        inline?: boolean;
        required?: boolean;
        requiredLabel?: string;
        skin?: '1' | '2' | '3' | '4' | '5' | '6' | 'functional';
        warning?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
declare class Legend extends Component<LegendSignature> {
    get skin(): "au-u-h1" | "au-u-h2" | "au-u-h3" | "au-u-h4" | "au-u-h5" | "au-u-h6" | "au-u-h-functional";
    get inline(): "" | "au-c-fieldset-legend--inline";
    get error(): "" | "au-c-fieldset-legend--error";
    get warning(): "" | "au-c-fieldset-legend--warning";
}
interface ContentSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
declare const Content: TOC<ContentSignature>;
export {};
//# sourceMappingURL=au-fieldset.d.ts.map