import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuPillSignature {
    Args: {
        actionIcon?: AuIconSignature['Args']['icon'];
        actionText?: string;
        draft?: boolean;
        href?: string;
        model?: unknown;
        models?: unknown[];
        onClickAction?: () => void;
        route?: string;
        size?: 'small';
        skin?: 'action' | 'border' | 'error' | 'link' | 'ongoing' | 'success' | 'warning';
        query?: Record<string, unknown>;
    } & InnerSignature['Args'];
    Blocks: {
        default: [];
    };
    Element: HTMLSpanElement | HTMLAnchorElement;
}
export default class AuPill extends Component<AuPillSignature> {
    get skin(): "au-c-pill--border" | "au-c-pill--ongoing" | "au-c-pill--link" | "au-c-pill--success" | "au-c-pill--warning" | "au-c-pill--error" | "au-c-pill--default";
    get size(): string;
    get actionSize(): string;
    get draft(): "" | "au-c-pill--draft";
    get queryParams(): Record<string, unknown>;
}
interface InnerSignature {
    Args: {
        icon?: AuIconSignature['Args']['icon'];
        iconAlignment?: 'left' | 'right';
        hideText?: boolean;
    };
    Blocks: {
        default: [];
    };
}
export {};
//# sourceMappingURL=au-pill.d.ts.map