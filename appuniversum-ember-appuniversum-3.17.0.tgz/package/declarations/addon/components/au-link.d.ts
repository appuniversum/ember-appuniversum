import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuLinkSignature {
    Args: {
        active?: boolean;
        skin?: 'primary' | 'secondary' | 'bold' | 'button' | 'button-secondary' | 'button-naked';
        width?: 'block';
        query?: Record<string, unknown>;
        icon?: AuIconSignature['Args']['icon'];
        route: string;
        hideText?: boolean;
        model?: unknown;
        models?: unknown[];
        iconAlignment?: 'left' | 'right';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLAnchorElement;
}
export default class AuLink extends Component<AuLinkSignature> {
    get skinClass(): string;
    get widthClass(): "" | "au-c-button--block" | "au-c-link--block";
    get activeClass(): "" | "is-active";
    get queryParams(): Record<string, unknown>;
    get isIconLeft(): boolean;
    get isIconRight(): boolean;
    get iconAlignment(): "left" | "right";
    get iconOnlyClass(): "" | "au-c-button--icon-only" | "au-c-link--icon-only";
}
//# sourceMappingURL=au-link.d.ts.map