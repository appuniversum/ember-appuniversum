import Component from '@glimmer/component';
export interface AuToggleSwitchSignature {
    Args: {
        alignment?: 'right';
        checked?: boolean;
        disabled?: boolean;
        identifier?: string;
        label?: string;
        name?: string;
        onChange?: (checked: boolean, event: Event) => void;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLInputElement;
}
export default class AuToggleSwitch extends Component<AuToggleSwitchSignature> {
    get alignmentClass(): "" | "au-c-toggle-switch--alignment-right";
    onChange(event: Event): void;
}
//# sourceMappingURL=au-toggle-switch.d.ts.map