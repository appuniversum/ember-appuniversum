import Component from '@glimmer/component';
export interface AuHelpTextSignature {
    Args: {
        skin?: 'secondary' | 'tertiary';
        size?: 'normal' | 'large';
        error?: boolean;
        warning?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLSpanElement;
}
export default class AuHelpText extends Component<AuHelpTextSignature> {
    get skin(): "" | "au-c-help-text--secondary" | "au-c-help-text--tertiary";
    get size(): "" | "au-c-help-text--normal" | "au-c-help-text--large";
    get error(): "" | "au-c-help-text--error";
    get warning(): "" | "au-c-help-text--warning";
}
//# sourceMappingURL=au-help-text.d.ts.map