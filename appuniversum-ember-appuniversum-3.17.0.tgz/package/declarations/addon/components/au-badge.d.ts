import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuBadgeSignature {
    Args: {
        icon?: AuIconSignature['Args']['icon'];
        iconVisible?: boolean;
        number?: number;
        size?: 'small';
        skin?: 'action' | 'border' | 'brand' | 'error' | 'success' | 'warning';
    };
    Element: HTMLSpanElement;
}
export default class AuBadge extends Component<AuBadgeSignature> {
    get skin(): string;
    get size(): "" | "au-c-badge--small";
}
//# sourceMappingURL=au-badge.d.ts.map