import type { TOC } from '@ember/component/template-only';
export interface AuMainFooterSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
declare const AuMainFooter: TOC<AuMainFooterSignature>;
export default AuMainFooter;
//# sourceMappingURL=au-main-footer.d.ts.map