import Component from '@glimmer/component';
import type { DuetDatePickerChangeEvent } from '@duetds/date-picker/dist/types/components/duet-date-picker/duet-date-picker';
import type { DuetLocalizedText } from '@duetds/date-picker/dist/types/components/duet-date-picker/date-localization';
import type { DuetDateAdapter } from '@duetds/date-picker/dist/types/components/duet-date-picker/date-adapter';
type IsoDate = string;
type Adapter = DuetDateAdapter;
type Localization = DuetLocalizedText;
type DayOfWeek = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export interface AuDatePickerSignature {
    Args: {
        alignment?: 'top';
        adapter?: Adapter;
        buttonLabel?: string;
        disabled?: boolean;
        error?: boolean;
        'first-day'?: DayOfWeek;
        firstDay?: DayOfWeek;
        id?: string;
        label?: string;
        localization?: Localization;
        max?: IsoDate | Date;
        min?: IsoDate | Date;
        value?: IsoDate | Date;
        warning?: boolean;
        onChange?: (isoDate: IsoDate | null, date: Date | null) => void;
    };
    Element: HTMLDuetDatePickerElement;
}
export default class AuDatePicker extends Component<AuDatePickerSignature> {
    value: IsoDate;
    min: IsoDate;
    max: IsoDate;
    isInitialized: boolean;
    constructor(owner: unknown, args: AuDatePickerSignature['Args']);
    get adapter(): DuetDateAdapter;
    get id(): string;
    get localization(): DuetLocalizedText;
    get error(): "" | "duet-date-error" | "duet-date-warning";
    get alignment(): "" | "au-c-datepicker--top";
    get firstDayOfWeek(): DayOfWeek | undefined;
    handleDuetDateChange(event: CustomEvent<DuetDatePickerChangeEvent>): void;
    registerDuetDatePicker(): Promise<void>;
}
export {};
//# sourceMappingURL=au-date-picker.d.ts.map