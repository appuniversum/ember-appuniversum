import Component from '@glimmer/component';
import type { FileQueueService, UploadFile } from 'ember-file-upload';
export interface AuFileUploadSignature {
    Args: {
        accept?: string;
        endPoint?: string;
        helpTextDragDrop?: string;
        helpTextFileNotSupported?: string;
        maxFileSizeMB?: number;
        minFileSizeKB?: number;
        multiple?: boolean;
        onFinishUpload?: (uploadedFile: number, queueInfo: QueueInfo) => void;
        onUpload?: (data: {
            fileId: unknown;
            file: UploadFile;
        }) => void;
        onQueueUpdate?: (queueInfo: QueueInfo) => void;
        title?: string;
    };
    Element: HTMLElement;
}
export type QueueInfo = {
    isQueueEmpty: boolean;
};
type BasicFile = {
    name: string;
    type: string;
};
type UploadError = {
    filename: string;
    error?: string;
};
export default class AuFileUpload extends Component<AuFileUploadSignature> {
    fileQueue: FileQueueService;
    uploadErrorData: UploadError[];
    get uploadingMsg(): string;
    get title(): string;
    get helpTextDragDrop(): string;
    get helpTextFileNotSupported(): string;
    get queueName(): string;
    get queue(): import("ember-file-upload").Queue;
    get endPoint(): string;
    get maxFileSizeMB(): number;
    get minFileSizeKB(): number;
    get hasErrors(): boolean;
    upload(file: UploadFile): void | undefined;
    uploadTask: import("ember-concurrency").TaskForAsyncTaskFunction<unknown, (file: UploadFile) => Promise<void>>;
    uploadFileTask: import("ember-concurrency").TaskForAsyncTaskFunction<{
        enqueue: boolean;
        maxConcurrency: number;
    }, (file: UploadFile) => Promise<number | null>>;
    filter(file: File, files: File[], index: number): boolean;
    notifyQueueUpdate(): void;
    calculateQueueInfo(): QueueInfo;
    addError(file: BasicFile, errorMessage?: string): void;
    resetErrors(): void;
    removeFileFromQueue(file: UploadFile): void;
}
export declare function isValidFileType(file: Partial<BasicFile>, accept?: string): boolean;
export {};
//# sourceMappingURL=au-file-upload.d.ts.map