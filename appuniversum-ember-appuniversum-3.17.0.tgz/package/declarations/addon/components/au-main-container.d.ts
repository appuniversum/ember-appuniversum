import type { TOC } from '@ember/component/template-only';
import Component from '@glimmer/component';
export interface AuMainContainerSignature {
    Element: HTMLElement;
    Blocks: {
        default: [
            {
                sidebar?: typeof Sidebar;
                content?: typeof Content;
            }
        ];
    };
}
declare const AuMainContainer: TOC<AuMainContainerSignature>;
export default AuMainContainer;
interface SidebarSignature {
    Args: {
        size?: 'collapsed' | 'small' | 'large';
    };
    Element: HTMLDivElement;
    Blocks: {
        default: [];
    };
}
declare class Sidebar extends Component<SidebarSignature> {
    get size(): "" | "au-c-main-container__sidebar--collapsed" | "au-c-main-container__sidebar--small" | "au-c-main-container__sidebar--large";
}
interface ContentSignature {
    Args: {
        scroll?: boolean;
    };
    Element: HTMLDivElement;
    Blocks: {
        default: [];
    };
}
declare class Content extends Component<ContentSignature> {
    get scroll(): "" | "au-c-main-container__content--scroll";
}
//# sourceMappingURL=au-main-container.d.ts.map