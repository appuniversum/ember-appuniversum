import Component from '@glimmer/component';
export interface AuLoaderSignature {
    Args: {
        inline?: boolean;
        hideMessage?: boolean;
        centered?: boolean;
        disableMessage?: boolean;
        message?: string;
        padding?: 'small' | 'large';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuLoader extends Component<AuLoaderSignature> {
    get padding(): "" | "au-c-loader--small" | "au-c-loader--large";
    get message(): string;
    get centered(): "" | "au-u-text-center";
}
//# sourceMappingURL=au-loader.d.ts.map