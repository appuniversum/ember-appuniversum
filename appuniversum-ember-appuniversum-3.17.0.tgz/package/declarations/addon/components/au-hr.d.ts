import Component from '@glimmer/component';
export interface AuHrSignature {
    Args: {
        size?: 'large' | 'huge';
    };
    Element: HTMLHRElement;
}
export default class AuHr extends Component<AuHrSignature> {
    get size(): "" | "au-c-hr--large" | "au-c-hr--huge";
}
//# sourceMappingURL=au-hr.d.ts.map