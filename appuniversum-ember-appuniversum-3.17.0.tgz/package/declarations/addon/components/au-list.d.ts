import Component from '@glimmer/component';
export interface AuListSignature {
    Args: {
        direction?: 'horizontal';
        divider?: boolean;
    };
    Blocks: {
        default: [typeof ListItem];
    };
    Element: HTMLUListElement;
}
export default class AuList extends Component<AuListSignature> {
    get direction(): "au-c-list--horizontal" | "au-c-list--vertical";
    get divider(): "" | "au-c-list--divider";
}
interface ListItemSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLLIElement;
}
declare class ListItem extends Component<ListItemSignature> {
}
export {};
//# sourceMappingURL=au-list.d.ts.map