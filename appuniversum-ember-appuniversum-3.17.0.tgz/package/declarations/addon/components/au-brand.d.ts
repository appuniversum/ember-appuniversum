import Component from '@glimmer/component';
export interface AuBrandSignature {
    Args: {
        link?: string;
        tagline?: string;
    };
    Element: HTMLDivElement | HTMLAnchorElement;
}
export default class AuBrand extends Component<AuBrandSignature> {
    id: string;
    get tagline(): "" | "au-c-brand--tagline";
}
//# sourceMappingURL=au-brand.d.ts.map