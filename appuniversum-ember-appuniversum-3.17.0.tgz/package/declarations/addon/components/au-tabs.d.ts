import type { TOC } from '@ember/component/template-only';
export interface AuTabsSignature {
    Args: {
        reversed?: boolean;
    };
    Blocks: {
        default: [typeof Tab];
    };
    Element: HTMLElement;
}
declare const AuTabs: TOC<AuTabsSignature>;
export default AuTabs;
interface TabSignature {
    Blocks: {
        default: [];
    };
    Element: HTMLLIElement;
}
declare const Tab: TOC<TabSignature>;
//# sourceMappingURL=au-tabs.d.ts.map