import Component from '@glimmer/component';
import type { ModifierLike, WithBoundArgs } from '@glint/template';
export interface AuTooltipSignature {
    Args: {
        placement?: 'top' | 'right' | 'bottom' | 'left';
    };
    Blocks: {
        default: [
            {
                Content: WithBoundArgs<typeof TooltipContent, 'targetElement' | 'isShown' | 'placement' | 'show' | 'hide' | 'hideInstantly'>;
                isShown: boolean;
                target: ModifierLike<{
                    Element: HTMLElement;
                }>;
            }
        ];
    };
}
export default class AuTooltip extends Component<AuTooltipSignature> {
    targetElement: HTMLElement;
    isShown: boolean;
    delayTimeoutId?: number;
    get placement(): "left" | "right" | "top" | "bottom";
    show: () => void;
    hide: () => void;
    hideInstantly: () => void;
    clearDelayTimer(): void;
    target: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
}
interface TooltipContentSignature {
    Args: {
        targetElement: HTMLElement;
        isShown: boolean;
        placement: NonNullable<AuTooltipSignature['Args']['placement']>;
        show: () => void;
        hide: () => void;
        hideInstantly: () => void;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
declare class TooltipContent extends Component<TooltipContentSignature> {
    arrowElement: HTMLElement;
    arrow: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
    closeOnEscapePress: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: Element;
    }>;
    get floatingUiOptions(): {
        floater: {
            offset: number;
        };
    };
}
export {};
//# sourceMappingURL=au-tooltip.d.ts.map