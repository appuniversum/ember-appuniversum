import type { TOC } from '@ember/component/template-only';
import Component from '@glimmer/component';
import type ApplicationInstance from '@ember/application/instance';
import type ModalContainerService from '../services/modal-container';
export interface AuModalSignature {
    Args: {
        closable?: boolean;
        closeModal?: () => void;
        id?: string;
        initialFocus?: string;
        modalOpen?: boolean;
        overflow?: boolean;
        padding?: 'none';
        size?: 'large' | 'fullscreen';
        title?: string;
    };
    Blocks: {
        body: [];
        footer: [];
        title: [];
        default: [
            {
                Body: typeof Body;
                Footer: typeof Footer;
            }
        ];
    };
    Element: HTMLDivElement;
}
export default class AuModal extends Component<AuModalSignature> {
    destinationElement: HTMLElement;
    modalContainer: ModalContainerService;
    constructor(owner: ApplicationInstance, args: AuModalSignature['Args']);
    get docRoot(): HTMLElement;
    get size(): "" | "au-c-modal--fullscreen" | "au-c-modal--large";
    get padding(): "" | "au-c-modal--flush";
    get overflow(): "" | "au-c-modal--overflow";
    get initialFocus(): string;
    getInitialFocus: () => HTMLElement | undefined;
    get fallbackFocus(): string;
    getFallbackFocus: () => HTMLElement;
    get additionalElements(): string[];
    get isClosable(): boolean;
    handleCloseClick(): void;
    handleEscapePress(): boolean;
    closeModal(): void;
}
declare const Body: TOC<{
    Blocks: {
        default: [];
    };
}>;
declare const Footer: TOC<{
    Blocks: {
        default: [];
    };
}>;
export {};
//# sourceMappingURL=au-modal.d.ts.map