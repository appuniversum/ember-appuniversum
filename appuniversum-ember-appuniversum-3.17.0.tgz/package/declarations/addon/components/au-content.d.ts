import Component from '@glimmer/component';
export interface AuContentSignature {
    Args: {
        skin?: 'tiny' | 'small' | 'large';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuContent extends Component<AuContentSignature> {
    get skin(): "" | "au-c-content--tiny" | "au-c-content--small" | "au-c-content--large";
}
//# sourceMappingURL=au-content.d.ts.map