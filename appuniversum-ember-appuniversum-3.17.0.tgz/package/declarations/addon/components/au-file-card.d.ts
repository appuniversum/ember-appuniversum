import Component from '@glimmer/component';
export interface AuFileCardSignature {
    Args: {
        filename: string;
        fileSize?: string;
        downloadLink?: string;
        onDelete?: () => void;
    };
    Element: HTMLElement;
}
export default class AuFileCard extends Component<AuFileCardSignature> {
    get isRemovable(): boolean;
    get isDownloadable(): boolean;
    delete(event: Event): void;
}
//# sourceMappingURL=au-file-card.d.ts.map