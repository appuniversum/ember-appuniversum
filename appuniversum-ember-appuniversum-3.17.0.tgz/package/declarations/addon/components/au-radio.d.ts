import Component from '@glimmer/component';
interface PrivateArgs {
    groupValue?: unknown;
    inGroup?: boolean;
    onChangeGroup?: (selected: string | undefined, event: Event) => void;
}
export interface AuRadioSignature {
    Args: {
        checked?: boolean;
        disabled?: boolean;
        name?: string;
        onChange?: (selected: string, event: Event) => void;
        value?: string;
    } & PrivateArgs;
    Blocks: {
        default: [];
    };
    Element: HTMLInputElement;
}
export default class AuRadio extends Component<AuRadioSignature> {
    get checked(): boolean | undefined;
    onChange(event: Event): void;
}
export {};
//# sourceMappingURL=au-radio.d.ts.map