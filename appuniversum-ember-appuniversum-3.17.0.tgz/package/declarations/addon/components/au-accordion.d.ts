import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuAccordionSignature {
    Args: {
        buttonLabel?: string;
        iconClosed?: AuIconSignature['Args']['icon'];
        iconOpen?: AuIconSignature['Args']['icon'];
        isOpenInitially?: boolean;
        loading?: boolean;
        reverse?: boolean;
        skin?: 'border';
        subtitle?: string;
        disableAuContent?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuAccordion extends Component<AuAccordionSignature> {
    isOpen: boolean;
    constructor(owner: unknown, args: AuAccordionSignature['Args']);
    get loading(): "" | "is-loading";
    get iconOpen(): string | import("@glint/template").ComponentLike<{
        Element: Element;
    }> | import("@ember/component/template-only").TOC<import("./icons/nav-down").NavDownIconSignature>;
    get iconClosed(): string | import("@glint/template").ComponentLike<{
        Element: Element;
    }> | import("@ember/component/template-only").TOC<import("./icons/nav-right").NavRightIconSignature>;
    get skin(): "" | "au-c-accordion--border";
    get reverse(): "" | "au-c-accordion--reverse";
    toggleAccordion(): void;
}
//# sourceMappingURL=au-accordion.d.ts.map