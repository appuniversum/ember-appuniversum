import Component from '@glimmer/component';
export interface AuLabelSignature {
    Args: {
        error?: boolean;
        inline?: boolean;
        required?: boolean;
        requiredLabel?: string;
        warning?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLLabelElement;
}
export default class AuLabel extends Component<AuLabelSignature> {
    get inline(): "" | "au-c-label--inline";
    get error(): "" | "au-c-label--error";
    get warning(): "" | "au-c-label--warning";
}
//# sourceMappingURL=au-label.d.ts.map