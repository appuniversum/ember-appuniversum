import Component from '@glimmer/component';
export interface AuNavigationLinkSignature {
    Args: {
        model?: unknown;
        models?: unknown[];
        query?: Record<string, unknown>;
        route: string;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLAnchorElement;
}
export default class AuNavigationLink extends Component<AuNavigationLinkSignature> {
    get queryParams(): Record<string, unknown>;
    linkFocus(event: MouseEvent): void;
}
//# sourceMappingURL=au-navigation-link.d.ts.map