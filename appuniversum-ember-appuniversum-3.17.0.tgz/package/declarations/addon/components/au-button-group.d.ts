import Component from '@glimmer/component';
export interface AuButtonGroupSignature {
    Args: {
        inline?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuButtonGroup extends Component<AuButtonGroupSignature> {
    get inline(): "" | "au-c-button-group--inline";
}
//# sourceMappingURL=au-button-group.d.ts.map