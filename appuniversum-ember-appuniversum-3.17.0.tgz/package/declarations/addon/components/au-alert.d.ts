import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuAlertSignature {
    Args: {
        closable?: boolean;
        icon?: AuIconSignature['Args']['icon'];
        iconVisible?: boolean;
        onClose?: () => void;
        size?: 'tiny' | 'small';
        skin?: 'info' | 'success' | 'warning' | 'error';
        title?: string;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuAlert extends Component<AuAlertSignature> {
    isVisible: boolean;
    get skin(): "" | "au-c-alert--info" | "au-c-alert--success" | "au-c-alert--warning" | "au-c-alert--error";
    get size(): "" | "au-c-alert--tiny" | "au-c-alert--small";
    closeAlert(): void;
}
//# sourceMappingURL=au-alert.d.ts.map