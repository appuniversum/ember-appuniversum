import Component from '@glimmer/component';
export interface AuMainHeaderSignature {
    Args: {
        appTitle: string;
        brandLink?: string;
        contactRoute?: string;
        contactLabel?: string;
        homeRoute?: string;
        navigationAriaLabel?: string;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class AuMainHeader extends Component<AuMainHeaderSignature> {
    get contactLabel(): string;
    get navigationAriaLabel(): string;
    headerLinkFocus(): void;
}
//# sourceMappingURL=au-main-header.d.ts.map