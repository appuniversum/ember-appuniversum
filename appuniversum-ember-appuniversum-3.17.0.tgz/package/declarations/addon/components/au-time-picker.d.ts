import Component from '@glimmer/component';
export interface AuTimePickerSignature {
    Args: {
        hours?: number;
        hoursLabel?: string;
        minutes?: number;
        minutesLabel?: string;
        nowLabel?: string;
        onChange?: (data: TimeData) => void;
        seconds?: number;
        secondsLabel?: string;
        showNow?: boolean;
        showSeconds?: boolean;
    };
}
type TimeData = {
    hours: number;
    minutes: number;
    seconds: number;
};
type TimeProperty = 'hours' | 'minutes' | 'seconds';
export default class AuTimePicker extends Component<AuTimePickerSignature> {
    hours: number;
    minutes: number;
    seconds: number;
    get timeData(): TimeData;
    get showSeconds(): boolean;
    get showNow(): boolean;
    increment(propertyName: TimeProperty): void;
    decrement(propertyName: TimeProperty): void;
    timeValueKeyPress(type: TimeProperty, event: KeyboardEvent): void;
    validateTime(type: TimeProperty, event: Event): void;
    normalizeTimeValue(value: number, type: TimeProperty): number;
    onChange(value: TimeData): void;
    setCurrentTime(): void;
}
export {};
//# sourceMappingURL=au-time-picker.d.ts.map