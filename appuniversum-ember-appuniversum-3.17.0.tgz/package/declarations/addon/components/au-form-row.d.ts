import Component from '@glimmer/component';
export interface AuFormRowSignature {
    Args: {
        alignment?: 'inline' | 'pre' | 'post';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLDivElement;
}
export default class AuFormRow extends Component<AuFormRowSignature> {
    get alignment(): "" | "au-c-form-row--inline" | "au-c-form-row--inline au-c-form-row--pre" | "au-c-form-row--inline au-c-form-row--post";
}
//# sourceMappingURL=au-form-row.d.ts.map