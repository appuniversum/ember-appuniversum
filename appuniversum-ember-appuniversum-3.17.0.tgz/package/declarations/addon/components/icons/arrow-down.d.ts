import type { TOC } from '@ember/component/template-only';
export interface ArrowDownIconSignature {
    Element: SVGSVGElement;
}
export declare const ArrowDownIcon: TOC<ArrowDownIconSignature>;
//# sourceMappingURL=arrow-down.d.ts.map