import type { TOC } from '@ember/component/template-only';
export interface ExternalIconSignature {
    Element: SVGSVGElement;
}
export declare const ExternalIcon: TOC<ExternalIconSignature>;
//# sourceMappingURL=external.d.ts.map