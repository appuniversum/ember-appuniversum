import type { TOC } from '@ember/component/template-only';
export interface CaretDownIconSignature {
    Element: SVGSVGElement;
}
export declare const CaretDownIcon: TOC<CaretDownIconSignature>;
//# sourceMappingURL=caret-down.d.ts.map