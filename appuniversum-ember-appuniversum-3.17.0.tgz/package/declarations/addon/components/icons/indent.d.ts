import type { TOC } from '@ember/component/template-only';
export interface IndentIconSignature {
    Element: SVGSVGElement;
}
export declare const IndentIcon: TOC<IndentIconSignature>;
//# sourceMappingURL=indent.d.ts.map