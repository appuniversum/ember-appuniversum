import type { TOC } from '@ember/component/template-only';
export interface AlignRightIconSignature {
    Element: SVGSVGElement;
}
export declare const AlignRightIcon: TOC<AlignRightIconSignature>;
//# sourceMappingURL=align-right.d.ts.map