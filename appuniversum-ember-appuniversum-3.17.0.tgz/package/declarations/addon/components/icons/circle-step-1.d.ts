import type { TOC } from '@ember/component/template-only';
export interface CircleStep1IconSignature {
    Element: SVGSVGElement;
}
export declare const CircleStep1Icon: TOC<CircleStep1IconSignature>;
//# sourceMappingURL=circle-step-1.d.ts.map