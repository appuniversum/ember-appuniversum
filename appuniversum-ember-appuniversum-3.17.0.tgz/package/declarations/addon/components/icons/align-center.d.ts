import type { TOC } from '@ember/component/template-only';
export interface AlignCenterIconSignature {
    Element: SVGSVGElement;
}
export declare const AlignCenterIcon: TOC<AlignCenterIconSignature>;
//# sourceMappingURL=align-center.d.ts.map