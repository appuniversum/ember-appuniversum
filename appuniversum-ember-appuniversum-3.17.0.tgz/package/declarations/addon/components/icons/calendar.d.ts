import type { TOC } from '@ember/component/template-only';
export interface CalendarIconSignature {
    Element: SVGSVGElement;
}
export declare const CalendarIcon: TOC<CalendarIconSignature>;
//# sourceMappingURL=calendar.d.ts.map