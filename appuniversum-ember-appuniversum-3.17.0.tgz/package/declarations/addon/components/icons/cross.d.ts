import type { TOC } from '@ember/component/template-only';
export interface CrossIconSignature {
    Element: SVGSVGElement;
}
export declare const CrossIcon: TOC<CrossIconSignature>;
//# sourceMappingURL=cross.d.ts.map