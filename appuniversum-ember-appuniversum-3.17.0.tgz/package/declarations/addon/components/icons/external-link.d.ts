import type { TOC } from '@ember/component/template-only';
export interface ExternalLinkIconSignature {
    Element: SVGSVGElement;
}
export declare const ExternalLinkIcon: TOC<ExternalLinkIconSignature>;
//# sourceMappingURL=external-link.d.ts.map