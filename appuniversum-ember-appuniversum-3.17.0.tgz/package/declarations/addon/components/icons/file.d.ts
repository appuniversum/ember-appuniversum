import type { TOC } from '@ember/component/template-only';
export interface FileIconSignature {
    Element: SVGSVGElement;
}
export declare const FileIcon: TOC<FileIconSignature>;
//# sourceMappingURL=file.d.ts.map