import type { TOC } from '@ember/component/template-only';
export interface PencilIconSignature {
    Element: SVGSVGElement;
}
export declare const PencilIcon: TOC<PencilIconSignature>;
//# sourceMappingURL=pencil.d.ts.map