import type { TOC } from '@ember/component/template-only';
export interface LinkIconSignature {
    Element: SVGSVGElement;
}
export declare const LinkIcon: TOC<LinkIconSignature>;
//# sourceMappingURL=link.d.ts.map