import type { TOC } from '@ember/component/template-only';
export interface FilterIconSignature {
    Element: SVGSVGElement;
}
export declare const FilterIcon: TOC<FilterIconSignature>;
//# sourceMappingURL=filter.d.ts.map