import type { TOC } from '@ember/component/template-only';
export interface SwitchIconSignature {
    Element: SVGSVGElement;
}
export declare const SwitchIcon: TOC<SwitchIconSignature>;
//# sourceMappingURL=switch.d.ts.map