import type { TOC } from '@ember/component/template-only';
export interface ReportIconSignature {
    Element: SVGSVGElement;
}
export declare const ReportIcon: TOC<ReportIconSignature>;
//# sourceMappingURL=report.d.ts.map