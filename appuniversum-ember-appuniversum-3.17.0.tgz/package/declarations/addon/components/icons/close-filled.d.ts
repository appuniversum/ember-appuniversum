import type { TOC } from '@ember/component/template-only';
export interface CloseFilledIconSignature {
    Element: SVGSVGElement;
}
export declare const CloseFilledIcon: TOC<CloseFilledIconSignature>;
//# sourceMappingURL=close-filled.d.ts.map