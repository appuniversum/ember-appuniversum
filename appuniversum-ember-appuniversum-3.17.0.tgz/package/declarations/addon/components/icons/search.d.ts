import type { TOC } from '@ember/component/template-only';
export interface SearchIconSignature {
    Element: SVGSVGElement;
}
export declare const SearchIcon: TOC<SearchIconSignature>;
//# sourceMappingURL=search.d.ts.map