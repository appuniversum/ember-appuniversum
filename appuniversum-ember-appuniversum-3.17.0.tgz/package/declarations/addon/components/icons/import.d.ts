import type { TOC } from '@ember/component/template-only';
export interface ImportIconSignature {
    Element: SVGSVGElement;
}
export declare const ImportIcon: TOC<ImportIconSignature>;
//# sourceMappingURL=import.d.ts.map