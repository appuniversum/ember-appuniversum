import type { TOC } from '@ember/component/template-only';
export interface PlusIconSignature {
    Element: SVGSVGElement;
}
export declare const PlusIcon: TOC<PlusIconSignature>;
//# sourceMappingURL=plus.d.ts.map