import type { TOC } from '@ember/component/template-only';
export interface NavUpDoubleIconSignature {
    Element: SVGSVGElement;
}
export declare const NavUpDoubleIcon: TOC<NavUpDoubleIconSignature>;
//# sourceMappingURL=nav-up-double.d.ts.map