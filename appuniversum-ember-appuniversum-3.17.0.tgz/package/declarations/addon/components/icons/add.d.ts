import type { TOC } from '@ember/component/template-only';
export interface AddIconSignature {
    Element: SVGSVGElement;
}
export declare const AddIcon: TOC<AddIconSignature>;
//# sourceMappingURL=add.d.ts.map