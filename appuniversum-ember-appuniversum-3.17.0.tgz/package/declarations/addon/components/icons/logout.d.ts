import type { TOC } from '@ember/component/template-only';
export interface LogoutIconSignature {
    Element: SVGSVGElement;
}
export declare const LogoutIcon: TOC<LogoutIconSignature>;
//# sourceMappingURL=logout.d.ts.map