import type { TOC } from '@ember/component/template-only';
export interface CheckboxCheckedIconSignature {
    Element: SVGSVGElement;
}
export declare const CheckboxCheckedIcon: TOC<CheckboxCheckedIconSignature>;
//# sourceMappingURL=checkbox-checked.d.ts.map