import type { TOC } from '@ember/component/template-only';
export interface ChevronLeftIconSignature {
    Element: SVGSVGElement;
}
export declare const ChevronLeftIcon: TOC<ChevronLeftIconSignature>;
//# sourceMappingURL=chevron-left.d.ts.map