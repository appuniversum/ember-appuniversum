import type { TOC } from '@ember/component/template-only';
export interface ArrowLeftIconSignature {
    Element: SVGSVGElement;
}
export declare const ArrowLeftIcon: TOC<ArrowLeftIconSignature>;
//# sourceMappingURL=arrow-left.d.ts.map