import type { TOC } from '@ember/component/template-only';
export interface DragIconSignature {
    Element: SVGSVGElement;
}
export declare const DragIcon: TOC<DragIconSignature>;
//# sourceMappingURL=drag.d.ts.map