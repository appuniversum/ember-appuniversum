import type { TOC } from '@ember/component/template-only';
export interface LabelIconSignature {
    Element: SVGSVGElement;
}
export declare const LabelIcon: TOC<LabelIconSignature>;
//# sourceMappingURL=label.d.ts.map