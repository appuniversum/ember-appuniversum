import type { TOC } from '@ember/component/template-only';
export interface ParagraphIconSignature {
    Element: SVGSVGElement;
}
export declare const ParagraphIcon: TOC<ParagraphIconSignature>;
//# sourceMappingURL=paragraph.d.ts.map