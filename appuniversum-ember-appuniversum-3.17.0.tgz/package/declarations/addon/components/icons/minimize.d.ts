import type { TOC } from '@ember/component/template-only';
export interface MinimizeIconSignature {
    Element: SVGSVGElement;
}
export declare const MinimizeIcon: TOC<MinimizeIconSignature>;
//# sourceMappingURL=minimize.d.ts.map