import type { TOC } from '@ember/component/template-only';
export interface NavUpIconSignature {
    Element: SVGSVGElement;
}
export declare const NavUpIcon: TOC<NavUpIconSignature>;
//# sourceMappingURL=nav-up.d.ts.map