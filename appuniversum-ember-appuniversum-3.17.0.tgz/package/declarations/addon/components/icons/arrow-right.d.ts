import type { TOC } from '@ember/component/template-only';
export interface ArrowRightIconSignature {
    Element: SVGSVGElement;
}
export declare const ArrowRightIcon: TOC<ArrowRightIconSignature>;
//# sourceMappingURL=arrow-right.d.ts.map