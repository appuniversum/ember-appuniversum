import type { TOC } from '@ember/component/template-only';
export interface CheckFilledIconSignature {
    Element: SVGSVGElement;
}
export declare const CheckFilledIcon: TOC<CheckFilledIconSignature>;
//# sourceMappingURL=check-filled.d.ts.map