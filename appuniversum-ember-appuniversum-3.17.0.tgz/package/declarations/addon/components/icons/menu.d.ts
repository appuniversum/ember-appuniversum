import type { TOC } from '@ember/component/template-only';
export interface MenuIconSignature {
    Element: SVGSVGElement;
}
export declare const MenuIcon: TOC<MenuIconSignature>;
//# sourceMappingURL=menu.d.ts.map