import type { TOC } from '@ember/component/template-only';
export interface SignIconSignature {
    Element: SVGSVGElement;
}
export declare const SignIcon: TOC<SignIconSignature>;
//# sourceMappingURL=sign.d.ts.map