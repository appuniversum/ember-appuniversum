import type { TOC } from '@ember/component/template-only';
export interface AlertTriangleIconSignature {
    Element: SVGSVGElement;
}
export declare const AlertTriangleIcon: TOC<AlertTriangleIconSignature>;
//# sourceMappingURL=alert-triangle.d.ts.map