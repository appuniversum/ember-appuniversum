import type { TOC } from '@ember/component/template-only';
export interface CircleQuestionIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleQuestionIcon: TOC<CircleQuestionIconSignature>;
//# sourceMappingURL=circle-question.d.ts.map