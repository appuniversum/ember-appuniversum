import type { TOC } from '@ember/component/template-only';
export interface LockOpenIconSignature {
    Element: SVGSVGElement;
}
export declare const LockOpenIcon: TOC<LockOpenIconSignature>;
//# sourceMappingURL=lock-open.d.ts.map