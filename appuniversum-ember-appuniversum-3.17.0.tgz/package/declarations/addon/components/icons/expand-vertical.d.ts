import type { TOC } from '@ember/component/template-only';
export interface ExpandVerticalIconSignature {
    Element: SVGSVGElement;
}
export declare const ExpandVerticalIcon: TOC<ExpandVerticalIconSignature>;
//# sourceMappingURL=expand-vertical.d.ts.map