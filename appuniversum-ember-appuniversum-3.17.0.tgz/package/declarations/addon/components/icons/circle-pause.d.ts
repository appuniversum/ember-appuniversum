import type { TOC } from '@ember/component/template-only';
export interface CirclePauseIconSignature {
    Element: SVGSVGElement;
}
export declare const CirclePauseIcon: TOC<CirclePauseIconSignature>;
//# sourceMappingURL=circle-pause.d.ts.map