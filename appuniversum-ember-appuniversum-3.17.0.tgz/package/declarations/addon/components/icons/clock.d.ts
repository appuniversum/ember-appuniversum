import type { TOC } from '@ember/component/template-only';
export interface ClockIconSignature {
    Element: SVGSVGElement;
}
export declare const ClockIcon: TOC<ClockIconSignature>;
//# sourceMappingURL=clock.d.ts.map