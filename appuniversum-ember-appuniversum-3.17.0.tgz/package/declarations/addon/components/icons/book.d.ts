import type { TOC } from '@ember/component/template-only';
export interface BookIconSignature {
    Element: SVGSVGElement;
}
export declare const BookIcon: TOC<BookIconSignature>;
//# sourceMappingURL=book.d.ts.map