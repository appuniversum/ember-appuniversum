import type { TOC } from '@ember/component/template-only';
export interface SettingsIconSignature {
    Element: SVGSVGElement;
}
export declare const SettingsIcon: TOC<SettingsIconSignature>;
//# sourceMappingURL=settings.d.ts.map