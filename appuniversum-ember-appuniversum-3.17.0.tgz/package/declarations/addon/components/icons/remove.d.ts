import type { TOC } from '@ember/component/template-only';
export interface RemoveIconSignature {
    Element: SVGSVGElement;
}
export declare const RemoveIcon: TOC<RemoveIconSignature>;
//# sourceMappingURL=remove.d.ts.map