import type { TOC } from '@ember/component/template-only';
export interface CircleStep2IconSignature {
    Element: SVGSVGElement;
}
export declare const CircleStep2Icon: TOC<CircleStep2IconSignature>;
//# sourceMappingURL=circle-step-2.d.ts.map