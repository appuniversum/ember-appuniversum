import type { TOC } from '@ember/component/template-only';
export interface BoldIconSignature {
    Element: SVGSVGElement;
}
export declare const BoldIcon: TOC<BoldIconSignature>;
//# sourceMappingURL=bold.d.ts.map