import type { TOC } from '@ember/component/template-only';
export interface DownloadIconSignature {
    Element: SVGSVGElement;
}
export declare const DownloadIcon: TOC<DownloadIconSignature>;
//# sourceMappingURL=download.d.ts.map