import type { TOC } from '@ember/component/template-only';
export interface NavRightIconSignature {
    Element: SVGSVGElement;
}
export declare const NavRightIcon: TOC<NavRightIconSignature>;
//# sourceMappingURL=nav-right.d.ts.map