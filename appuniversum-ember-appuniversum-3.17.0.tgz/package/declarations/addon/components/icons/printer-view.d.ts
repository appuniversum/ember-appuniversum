import type { TOC } from '@ember/component/template-only';
export interface PrinterViewIconSignature {
    Element: SVGSVGElement;
}
export declare const PrinterViewIcon: TOC<PrinterViewIconSignature>;
//# sourceMappingURL=printer-view.d.ts.map