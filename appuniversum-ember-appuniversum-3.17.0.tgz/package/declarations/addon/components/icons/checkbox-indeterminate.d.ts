import type { TOC } from '@ember/component/template-only';
export interface CheckboxIndeterminateIconSignature {
    Element: SVGSVGElement;
}
export declare const CheckboxIndeterminateIcon: TOC<CheckboxIndeterminateIconSignature>;
//# sourceMappingURL=checkbox-indeterminate.d.ts.map