import type { TOC } from '@ember/component/template-only';
export interface StrikethroughIconSignature {
    Element: SVGSVGElement;
}
export declare const StrikethroughIcon: TOC<StrikethroughIconSignature>;
//# sourceMappingURL=strikethrough.d.ts.map