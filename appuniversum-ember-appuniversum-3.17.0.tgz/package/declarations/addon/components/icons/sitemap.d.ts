import type { TOC } from '@ember/component/template-only';
export interface SitemapIconSignature {
    Element: SVGSVGElement;
}
export declare const SitemapIcon: TOC<SitemapIconSignature>;
//# sourceMappingURL=sitemap.d.ts.map