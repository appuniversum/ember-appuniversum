import type { TOC } from '@ember/component/template-only';
export interface NoSignIconSignature {
    Element: SVGSVGElement;
}
export declare const NoSignIcon: TOC<NoSignIconSignature>;
//# sourceMappingURL=no-sign.d.ts.map