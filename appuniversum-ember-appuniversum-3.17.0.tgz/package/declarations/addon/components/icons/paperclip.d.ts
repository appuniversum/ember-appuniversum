import type { TOC } from '@ember/component/template-only';
export interface PaperclipIconSignature {
    Element: SVGSVGElement;
}
export declare const PaperclipIcon: TOC<PaperclipIconSignature>;
//# sourceMappingURL=paperclip.d.ts.map