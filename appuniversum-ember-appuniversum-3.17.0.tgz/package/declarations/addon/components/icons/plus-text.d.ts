import type { TOC } from '@ember/component/template-only';
export interface PlusTextIconSignature {
    Element: SVGSVGElement;
}
export declare const PlusTextIcon: TOC<PlusTextIconSignature>;
//# sourceMappingURL=plus-text.d.ts.map