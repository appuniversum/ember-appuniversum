import type { TOC } from '@ember/component/template-only';
export interface NavUpDownIconSignature {
    Element: SVGSVGElement;
}
export declare const NavUpDownIcon: TOC<NavUpDownIconSignature>;
//# sourceMappingURL=nav-up-down.d.ts.map