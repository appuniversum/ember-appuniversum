import type { TOC } from '@ember/component/template-only';
export interface ReverseIndentIconSignature {
    Element: SVGSVGElement;
}
export declare const ReverseIndentIcon: TOC<ReverseIndentIconSignature>;
//# sourceMappingURL=reverse-indent.d.ts.map