import type { TOC } from '@ember/component/template-only';
export interface CopyIconSignature {
    Element: SVGSVGElement;
}
export declare const CopyIcon: TOC<CopyIconSignature>;
//# sourceMappingURL=copy.d.ts.map