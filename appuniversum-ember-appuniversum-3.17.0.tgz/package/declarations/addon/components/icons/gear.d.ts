import type { TOC } from '@ember/component/template-only';
export interface GearIconSignature {
    Element: SVGSVGElement;
}
export declare const GearIcon: TOC<GearIconSignature>;
//# sourceMappingURL=gear.d.ts.map