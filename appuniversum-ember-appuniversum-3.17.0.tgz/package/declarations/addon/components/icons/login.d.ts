import type { TOC } from '@ember/component/template-only';
export interface LoginIconSignature {
    Element: SVGSVGElement;
}
export declare const LoginIcon: TOC<LoginIconSignature>;
//# sourceMappingURL=login.d.ts.map