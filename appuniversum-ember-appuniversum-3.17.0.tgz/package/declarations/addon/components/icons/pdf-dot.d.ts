import type { TOC } from '@ember/component/template-only';
export interface PdfDotIconSignature {
    Element: SVGSVGElement;
}
export declare const PdfDotIcon: TOC<PdfDotIconSignature>;
//# sourceMappingURL=pdf-dot.d.ts.map