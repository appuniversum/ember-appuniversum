import type { TOC } from '@ember/component/template-only';
export interface AlignLeftIconSignature {
    Element: SVGSVGElement;
}
export declare const AlignLeftIcon: TOC<AlignLeftIconSignature>;
//# sourceMappingURL=align-left.d.ts.map