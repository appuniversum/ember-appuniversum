import type { TOC } from '@ember/component/template-only';
export interface CircleInfoIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleInfoIcon: TOC<CircleInfoIconSignature>;
//# sourceMappingURL=circle-info.d.ts.map