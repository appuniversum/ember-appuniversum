import type { TOC } from '@ember/component/template-only';
export interface CheckboxUncheckedIconSignature {
    Element: SVGSVGElement;
}
export declare const CheckboxUncheckedIcon: TOC<CheckboxUncheckedIconSignature>;
//# sourceMappingURL=checkbox-unchecked.d.ts.map