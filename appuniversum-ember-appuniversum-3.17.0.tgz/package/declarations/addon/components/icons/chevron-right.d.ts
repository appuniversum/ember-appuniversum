import type { TOC } from '@ember/component/template-only';
export interface ChevronRightIconSignature {
    Element: SVGSVGElement;
}
export declare const ChevronRightIcon: TOC<ChevronRightIconSignature>;
//# sourceMappingURL=chevron-right.d.ts.map