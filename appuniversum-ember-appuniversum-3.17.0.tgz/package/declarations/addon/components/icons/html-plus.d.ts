import type { TOC } from '@ember/component/template-only';
export interface HtmlPlusIconSignature {
    Element: SVGSVGElement;
}
export declare const HtmlPlusIcon: TOC<HtmlPlusIconSignature>;
//# sourceMappingURL=html-plus.d.ts.map