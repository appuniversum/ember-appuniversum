import type { TOC } from '@ember/component/template-only';
export interface CircleStep6IconSignature {
    Element: SVGSVGElement;
}
export declare const CircleStep6Icon: TOC<CircleStep6IconSignature>;
//# sourceMappingURL=circle-step-6.d.ts.map