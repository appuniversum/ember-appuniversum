import type { TOC } from '@ember/component/template-only';
export interface DragHandle2IconSignature {
    Element: SVGSVGElement;
}
export declare const DragHandle2Icon: TOC<DragHandle2IconSignature>;
//# sourceMappingURL=drag-handle-2.d.ts.map