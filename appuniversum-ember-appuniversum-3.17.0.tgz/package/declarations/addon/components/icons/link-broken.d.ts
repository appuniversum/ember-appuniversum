import type { TOC } from '@ember/component/template-only';
export interface LinkBrokenIconSignature {
    Element: SVGSVGElement;
}
export declare const LinkBrokenIcon: TOC<LinkBrokenIconSignature>;
//# sourceMappingURL=link-broken.d.ts.map