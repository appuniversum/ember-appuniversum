import type { TOC } from '@ember/component/template-only';
export interface CircleStep3IconSignature {
    Element: SVGSVGElement;
}
export declare const CircleStep3Icon: TOC<CircleStep3IconSignature>;
//# sourceMappingURL=circle-step-3.d.ts.map