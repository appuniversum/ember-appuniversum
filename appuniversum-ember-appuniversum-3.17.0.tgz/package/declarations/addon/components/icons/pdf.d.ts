import type { TOC } from '@ember/component/template-only';
export interface PdfIconSignature {
    Element: SVGSVGElement;
}
export declare const PdfIcon: TOC<PdfIconSignature>;
//# sourceMappingURL=pdf.d.ts.map