import type { TOC } from '@ember/component/template-only';
export interface HtmlIconSignature {
    Element: SVGSVGElement;
}
export declare const HtmlIcon: TOC<HtmlIconSignature>;
//# sourceMappingURL=html.d.ts.map