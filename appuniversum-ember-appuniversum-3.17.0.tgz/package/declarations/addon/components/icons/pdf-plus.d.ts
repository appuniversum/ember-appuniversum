import type { TOC } from '@ember/component/template-only';
export interface PdfPlusIconSignature {
    Element: SVGSVGElement;
}
export declare const PdfPlusIcon: TOC<PdfPlusIconSignature>;
//# sourceMappingURL=pdf-plus.d.ts.map