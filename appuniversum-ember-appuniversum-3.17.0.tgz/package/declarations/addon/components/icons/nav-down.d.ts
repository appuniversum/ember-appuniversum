import type { TOC } from '@ember/component/template-only';
export interface NavDownIconSignature {
    Element: SVGSVGElement;
}
export declare const NavDownIcon: TOC<NavDownIconSignature>;
//# sourceMappingURL=nav-down.d.ts.map