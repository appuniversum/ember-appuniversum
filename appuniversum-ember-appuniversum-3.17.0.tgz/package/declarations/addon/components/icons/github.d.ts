import type { TOC } from '@ember/component/template-only';
export interface GithubIconSignature {
    Element: SVGSVGElement;
}
export declare const GithubIcon: TOC<GithubIconSignature>;
//# sourceMappingURL=github.d.ts.map