import type { TOC } from '@ember/component/template-only';
export interface CalendarNewIconSignature {
    Element: SVGSVGElement;
}
export declare const CalendarNewIcon: TOC<CalendarNewIconSignature>;
//# sourceMappingURL=calendar-new.d.ts.map