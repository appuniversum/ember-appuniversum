import type { TOC } from '@ember/component/template-only';
export interface ArrowUpIconSignature {
    Element: SVGSVGElement;
}
export declare const ArrowUpIcon: TOC<ArrowUpIconSignature>;
//# sourceMappingURL=arrow-up.d.ts.map