import type { TOC } from '@ember/component/template-only';
export interface FolderIconSignature {
    Element: SVGSVGElement;
}
export declare const FolderIcon: TOC<FolderIconSignature>;
//# sourceMappingURL=folder.d.ts.map