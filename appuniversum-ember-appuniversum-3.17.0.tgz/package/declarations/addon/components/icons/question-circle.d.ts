import type { TOC } from '@ember/component/template-only';
export interface QuestionCircleIconSignature {
    Element: SVGSVGElement;
}
export declare const QuestionCircleIcon: TOC<QuestionCircleIconSignature>;
//# sourceMappingURL=question-circle.d.ts.map