import type { TOC } from '@ember/component/template-only';
export interface CircleIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleIcon: TOC<CircleIconSignature>;
//# sourceMappingURL=circle.d.ts.map