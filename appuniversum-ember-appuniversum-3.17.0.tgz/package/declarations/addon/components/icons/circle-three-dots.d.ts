import type { TOC } from '@ember/component/template-only';
export interface CircleThreeDotsIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleThreeDotsIcon: TOC<CircleThreeDotsIconSignature>;
//# sourceMappingURL=circle-three-dots.d.ts.map