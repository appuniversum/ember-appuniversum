import type { TOC } from '@ember/component/template-only';
export interface RenewIconSignature {
    Element: SVGSVGElement;
}
export declare const RenewIcon: TOC<RenewIconSignature>;
//# sourceMappingURL=renew.d.ts.map