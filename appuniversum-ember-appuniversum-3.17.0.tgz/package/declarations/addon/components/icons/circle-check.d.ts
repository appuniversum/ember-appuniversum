import type { TOC } from '@ember/component/template-only';
export interface CircleCheckIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleCheckIcon: TOC<CircleCheckIconSignature>;
//# sourceMappingURL=circle-check.d.ts.map