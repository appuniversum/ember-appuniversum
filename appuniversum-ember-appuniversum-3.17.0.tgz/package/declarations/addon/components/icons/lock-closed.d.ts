import type { TOC } from '@ember/component/template-only';
export interface LockClosedIconSignature {
    Element: SVGSVGElement;
}
export declare const LockClosedIcon: TOC<LockClosedIconSignature>;
//# sourceMappingURL=lock-closed.d.ts.map