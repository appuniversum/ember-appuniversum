import type { TOC } from '@ember/component/template-only';
export interface ExportIconSignature {
    Element: SVGSVGElement;
}
export declare const ExportIcon: TOC<ExportIconSignature>;
//# sourceMappingURL=export.d.ts.map