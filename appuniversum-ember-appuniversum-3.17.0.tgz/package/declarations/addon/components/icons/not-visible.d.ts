import type { TOC } from '@ember/component/template-only';
export interface NotVisibleIconSignature {
    Element: SVGSVGElement;
}
export declare const NotVisibleIcon: TOC<NotVisibleIconSignature>;
//# sourceMappingURL=not-visible.d.ts.map