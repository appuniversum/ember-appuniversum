import type { TOC } from '@ember/component/template-only';
export interface CircleFullIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleFullIcon: TOC<CircleFullIconSignature>;
//# sourceMappingURL=circle-full.d.ts.map