import type { TOC } from '@ember/component/template-only';
export interface DraftIconSignature {
    Element: SVGSVGElement;
}
export declare const DraftIcon: TOC<DraftIconSignature>;
//# sourceMappingURL=draft.d.ts.map