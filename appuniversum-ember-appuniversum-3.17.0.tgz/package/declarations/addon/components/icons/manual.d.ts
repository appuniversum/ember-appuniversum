import type { TOC } from '@ember/component/template-only';
export interface ManualIconSignature {
    Element: SVGSVGElement;
}
export declare const ManualIcon: TOC<ManualIconSignature>;
//# sourceMappingURL=manual.d.ts.map