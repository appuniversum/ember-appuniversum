import type { TOC } from '@ember/component/template-only';
export interface HierarchalBackIconSignature {
    Element: SVGSVGElement;
}
export declare const HierarchalBackIcon: TOC<HierarchalBackIconSignature>;
//# sourceMappingURL=hierarchal-back.d.ts.map