import type { TOC } from '@ember/component/template-only';
export interface ItalicIconSignature {
    Element: SVGSVGElement;
}
export declare const ItalicIcon: TOC<ItalicIconSignature>;
//# sourceMappingURL=italic.d.ts.map