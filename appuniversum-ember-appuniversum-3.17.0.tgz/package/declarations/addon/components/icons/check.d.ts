import type { TOC } from '@ember/component/template-only';
export interface CheckIconSignature {
    Element: SVGSVGElement;
}
export declare const CheckIcon: TOC<CheckIconSignature>;
//# sourceMappingURL=check.d.ts.map