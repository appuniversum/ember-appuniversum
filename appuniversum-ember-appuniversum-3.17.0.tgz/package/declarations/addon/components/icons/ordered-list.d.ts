import type { TOC } from '@ember/component/template-only';
export interface OrderedListIconSignature {
    Element: SVGSVGElement;
}
export declare const OrderedListIcon: TOC<OrderedListIconSignature>;
//# sourceMappingURL=ordered-list.d.ts.map