import type { TOC } from '@ember/component/template-only';
export interface AttachmentIconSignature {
    Element: SVGSVGElement;
}
export declare const AttachmentIcon: TOC<AttachmentIconSignature>;
//# sourceMappingURL=attachment.d.ts.map