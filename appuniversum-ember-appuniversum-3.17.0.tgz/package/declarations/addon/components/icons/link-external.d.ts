import type { TOC } from '@ember/component/template-only';
export interface LinkExternalIconSignature {
    Element: SVGSVGElement;
}
export declare const LinkExternalIcon: TOC<LinkExternalIconSignature>;
//# sourceMappingURL=link-external.d.ts.map