import type { TOC } from '@ember/component/template-only';
export interface CaretUpIconSignature {
    Element: SVGSVGElement;
}
export declare const CaretUpIcon: TOC<CaretUpIconSignature>;
//# sourceMappingURL=caret-up.d.ts.map