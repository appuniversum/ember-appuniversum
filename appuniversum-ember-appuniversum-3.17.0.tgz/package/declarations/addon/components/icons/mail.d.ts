import type { TOC } from '@ember/component/template-only';
export interface MailIconSignature {
    Element: SVGSVGElement;
}
export declare const MailIcon: TOC<MailIconSignature>;
//# sourceMappingURL=mail.d.ts.map