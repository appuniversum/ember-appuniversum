import type { TOC } from '@ember/component/template-only';
export interface SubscriptIconSignature {
    Element: SVGSVGElement;
}
export declare const SubscriptIcon: TOC<SubscriptIconSignature>;
//# sourceMappingURL=subscript.d.ts.map