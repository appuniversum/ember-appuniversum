import type { TOC } from '@ember/component/template-only';
export interface CopyPasteIconSignature {
    Element: SVGSVGElement;
}
export declare const CopyPasteIcon: TOC<CopyPasteIconSignature>;
//# sourceMappingURL=copy-paste.d.ts.map