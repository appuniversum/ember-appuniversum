import type { TOC } from '@ember/component/template-only';
export interface MessageIconSignature {
    Element: SVGSVGElement;
}
export declare const MessageIcon: TOC<MessageIconSignature>;
//# sourceMappingURL=message.d.ts.map