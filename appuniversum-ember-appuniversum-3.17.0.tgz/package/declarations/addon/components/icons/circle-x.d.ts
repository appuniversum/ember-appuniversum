import type { TOC } from '@ember/component/template-only';
export interface CircleXIconSignature {
    Element: SVGSVGElement;
}
export declare const CircleXIcon: TOC<CircleXIconSignature>;
//# sourceMappingURL=circle-x.d.ts.map