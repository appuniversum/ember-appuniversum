import type { TOC } from '@ember/component/template-only';
export interface BookmarkIconSignature {
    Element: SVGSVGElement;
}
export declare const BookmarkIcon: TOC<BookmarkIconSignature>;
//# sourceMappingURL=bookmark.d.ts.map