import type { TOC } from '@ember/component/template-only';
export interface CaretUpDownIconSignature {
    Element: SVGSVGElement;
}
export declare const CaretUpDownIcon: TOC<CaretUpDownIconSignature>;
//# sourceMappingURL=caret-up-down.d.ts.map