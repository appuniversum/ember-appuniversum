import type { TOC } from '@ember/component/template-only';
export interface NavLeftIconSignature {
    Element: SVGSVGElement;
}
export declare const NavLeftIcon: TOC<NavLeftIconSignature>;
//# sourceMappingURL=nav-left.d.ts.map