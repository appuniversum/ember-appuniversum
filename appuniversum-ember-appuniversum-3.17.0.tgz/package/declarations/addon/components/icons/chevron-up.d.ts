import type { TOC } from '@ember/component/template-only';
export interface ChevronUpIconSignature {
    Element: SVGSVGElement;
}
export declare const ChevronUpIcon: TOC<ChevronUpIconSignature>;
//# sourceMappingURL=chevron-up.d.ts.map