import type { TOC } from '@ember/component/template-only';
export interface SuperscriptIconSignature {
    Element: SVGSVGElement;
}
export declare const SuperscriptIcon: TOC<SuperscriptIconSignature>;
//# sourceMappingURL=superscript.d.ts.map