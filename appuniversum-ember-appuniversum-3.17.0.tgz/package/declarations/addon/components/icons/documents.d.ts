import type { TOC } from '@ember/component/template-only';
export interface DocumentsIconSignature {
    Element: SVGSVGElement;
}
export declare const DocumentsIcon: TOC<DocumentsIconSignature>;
//# sourceMappingURL=documents.d.ts.map