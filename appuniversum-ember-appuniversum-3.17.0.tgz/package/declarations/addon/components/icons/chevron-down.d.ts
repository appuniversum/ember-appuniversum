import type { TOC } from '@ember/component/template-only';
export interface ChevronDownIconSignature {
    Element: SVGSVGElement;
}
export declare const ChevronDownIcon: TOC<ChevronDownIconSignature>;
//# sourceMappingURL=chevron-down.d.ts.map