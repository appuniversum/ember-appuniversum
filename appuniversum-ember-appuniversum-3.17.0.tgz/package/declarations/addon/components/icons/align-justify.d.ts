import type { TOC } from '@ember/component/template-only';
export interface AlignJustifyIconSignature {
    Element: SVGSVGElement;
}
export declare const AlignJustifyIcon: TOC<AlignJustifyIconSignature>;
//# sourceMappingURL=align-justify.d.ts.map