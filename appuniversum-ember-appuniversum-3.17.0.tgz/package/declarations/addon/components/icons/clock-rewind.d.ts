import type { TOC } from '@ember/component/template-only';
export interface ClockRewindIconSignature {
    Element: SVGSVGElement;
}
export declare const ClockRewindIcon: TOC<ClockRewindIconSignature>;
//# sourceMappingURL=clock-rewind.d.ts.map