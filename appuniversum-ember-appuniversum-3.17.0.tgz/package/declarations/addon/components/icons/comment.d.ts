import type { TOC } from '@ember/component/template-only';
export interface CommentIconSignature {
    Element: SVGSVGElement;
}
export declare const CommentIcon: TOC<CommentIconSignature>;
//# sourceMappingURL=comment.d.ts.map