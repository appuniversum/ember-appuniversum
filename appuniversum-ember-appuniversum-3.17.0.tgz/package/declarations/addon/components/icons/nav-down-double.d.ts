import type { TOC } from '@ember/component/template-only';
export interface NavDownDoubleIconSignature {
    Element: SVGSVGElement;
}
export declare const NavDownDoubleIcon: TOC<NavDownDoubleIconSignature>;
//# sourceMappingURL=nav-down-double.d.ts.map