import type { TOC } from '@ember/component/template-only';
export interface PrinterIconSignature {
    Element: SVGSVGElement;
}
export declare const PrinterIcon: TOC<PrinterIconSignature>;
//# sourceMappingURL=printer.d.ts.map