import type { TOC } from '@ember/component/template-only';
export interface ExpandHorizontalAltIconSignature {
    Element: SVGSVGElement;
}
export declare const ExpandHorizontalAltIcon: TOC<ExpandHorizontalAltIconSignature>;
//# sourceMappingURL=expand-horizontal-alt.d.ts.map