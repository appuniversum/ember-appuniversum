import type { TOC } from '@ember/component/template-only';
export interface DragHandleIconSignature {
    Element: SVGSVGElement;
}
export declare const DragHandleIcon: TOC<DragHandleIconSignature>;
//# sourceMappingURL=drag-handle.d.ts.map