import type { TOC } from '@ember/component/template-only';
export interface HtmlDotIconSignature {
    Element: SVGSVGElement;
}
export declare const HtmlDotIcon: TOC<HtmlDotIconSignature>;
//# sourceMappingURL=html-dot.d.ts.map