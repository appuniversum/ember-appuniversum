import type { TOC } from '@ember/component/template-only';
export interface CircleStep5IconSignature {
    Element: SVGSVGElement;
}
export declare const CircleStep5Icon: TOC<CircleStep5IconSignature>;
//# sourceMappingURL=circle-step-5.d.ts.map