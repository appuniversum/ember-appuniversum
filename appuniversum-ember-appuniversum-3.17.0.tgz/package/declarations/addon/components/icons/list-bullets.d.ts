import type { TOC } from '@ember/component/template-only';
export interface ListBulletsIconSignature {
    Element: SVGSVGElement;
}
export declare const ListBulletsIcon: TOC<ListBulletsIconSignature>;
//# sourceMappingURL=list-bullets.d.ts.map