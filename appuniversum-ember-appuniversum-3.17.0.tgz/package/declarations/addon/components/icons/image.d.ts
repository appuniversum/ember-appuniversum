import type { TOC } from '@ember/component/template-only';
export interface ImageIconSignature {
    Element: SVGSVGElement;
}
export declare const ImageIcon: TOC<ImageIconSignature>;
//# sourceMappingURL=image.d.ts.map