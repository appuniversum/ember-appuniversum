import type { TOC } from '@ember/component/template-only';
export interface SigninghubIconSignature {
    Element: SVGSVGElement;
}
export declare const SigninghubIcon: TOC<SigninghubIconSignature>;
//# sourceMappingURL=signinghub.d.ts.map