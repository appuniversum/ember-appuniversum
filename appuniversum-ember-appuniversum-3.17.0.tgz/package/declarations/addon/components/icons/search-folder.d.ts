import type { TOC } from '@ember/component/template-only';
export interface SearchFolderIconSignature {
    Element: SVGSVGElement;
}
export declare const SearchFolderIcon: TOC<SearchFolderIconSignature>;
//# sourceMappingURL=search-folder.d.ts.map