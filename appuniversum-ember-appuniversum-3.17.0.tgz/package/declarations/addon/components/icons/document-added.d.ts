import type { TOC } from '@ember/component/template-only';
export interface DocumentAddedIconSignature {
    Element: SVGSVGElement;
}
export declare const DocumentAddedIcon: TOC<DocumentAddedIconSignature>;
//# sourceMappingURL=document-added.d.ts.map