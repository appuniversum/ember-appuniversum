import type { TOC } from '@ember/component/template-only';
export interface DashIconSignature {
    Element: SVGSVGElement;
}
export declare const DashIcon: TOC<DashIconSignature>;
//# sourceMappingURL=dash.d.ts.map