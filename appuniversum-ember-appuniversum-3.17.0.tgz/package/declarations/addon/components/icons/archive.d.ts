import type { TOC } from '@ember/component/template-only';
export interface ArchiveIconSignature {
    Element: SVGSVGElement;
}
export declare const ArchiveIcon: TOC<ArchiveIconSignature>;
//# sourceMappingURL=archive.d.ts.map