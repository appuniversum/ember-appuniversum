import type { TOC } from '@ember/component/template-only';
export interface CircleStep4IconSignature {
    Element: SVGSVGElement;
}
export declare const CircleStep4Icon: TOC<CircleStep4IconSignature>;
//# sourceMappingURL=circle-step-4.d.ts.map