import type { TOC } from '@ember/component/template-only';
export interface HierarchicalBackIconSignature {
    Element: SVGSVGElement;
}
export declare const HierarchicalBackIcon: TOC<HierarchicalBackIconSignature>;
//# sourceMappingURL=hierarchical-back.d.ts.map