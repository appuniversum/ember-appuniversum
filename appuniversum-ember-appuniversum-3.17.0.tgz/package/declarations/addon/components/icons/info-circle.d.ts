import type { TOC } from '@ember/component/template-only';
export interface InfoCircleIconSignature {
    Element: SVGSVGElement;
}
export declare const InfoCircleIcon: TOC<InfoCircleIconSignature>;
//# sourceMappingURL=info-circle.d.ts.map