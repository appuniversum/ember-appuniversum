import type { TOC } from '@ember/component/template-only';
export interface LocationIconSignature {
    Element: SVGSVGElement;
}
export declare const LocationIcon: TOC<LocationIconSignature>;
//# sourceMappingURL=location.d.ts.map