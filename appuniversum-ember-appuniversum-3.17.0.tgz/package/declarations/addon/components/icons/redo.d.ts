import type { TOC } from '@ember/component/template-only';
export interface RedoIconSignature {
    Element: SVGSVGElement;
}
export declare const RedoIcon: TOC<RedoIconSignature>;
//# sourceMappingURL=redo.d.ts.map