import type { TOC } from '@ember/component/template-only';
export interface BinIconSignature {
    Element: SVGSVGElement;
}
export declare const BinIcon: TOC<BinIconSignature>;
//# sourceMappingURL=bin.d.ts.map