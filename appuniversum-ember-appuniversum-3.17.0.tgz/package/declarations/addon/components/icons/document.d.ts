import type { TOC } from '@ember/component/template-only';
export interface DocumentIconSignature {
    Element: SVGSVGElement;
}
export declare const DocumentIcon: TOC<DocumentIconSignature>;
//# sourceMappingURL=document.d.ts.map