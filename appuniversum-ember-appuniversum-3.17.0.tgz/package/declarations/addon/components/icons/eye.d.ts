import type { TOC } from '@ember/component/template-only';
export interface EyeIconSignature {
    Element: SVGSVGElement;
}
export declare const EyeIcon: TOC<EyeIconSignature>;
//# sourceMappingURL=eye.d.ts.map