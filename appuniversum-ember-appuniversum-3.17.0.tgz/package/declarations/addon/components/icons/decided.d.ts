import type { TOC } from '@ember/component/template-only';
export interface DecidedIconSignature {
    Element: SVGSVGElement;
}
export declare const DecidedIcon: TOC<DecidedIconSignature>;
//# sourceMappingURL=decided.d.ts.map