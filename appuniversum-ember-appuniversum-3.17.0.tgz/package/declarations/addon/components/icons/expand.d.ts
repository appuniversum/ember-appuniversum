import type { TOC } from '@ember/component/template-only';
export interface ExpandIconSignature {
    Element: SVGSVGElement;
}
export declare const ExpandIcon: TOC<ExpandIconSignature>;
//# sourceMappingURL=expand.d.ts.map