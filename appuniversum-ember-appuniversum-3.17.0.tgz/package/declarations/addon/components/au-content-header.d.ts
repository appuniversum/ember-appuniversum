import Component from '@glimmer/component';
export interface AuContentHeaderSignature {
    Args: {
        pictureSize?: 'large';
        titlePartOne?: string;
        titlePartTwo?: string;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class AuContentHeader extends Component<AuContentHeaderSignature> {
    get pictureSize(): "" | "au-c-content-header--large";
}
//# sourceMappingURL=au-content-header.d.ts.map