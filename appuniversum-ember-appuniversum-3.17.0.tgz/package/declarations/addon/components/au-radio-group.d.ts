import Component from '@glimmer/component';
import type { WithBoundArgs } from '@glint/template';
import AuRadio, { type AuRadioSignature } from './au-radio';
export interface AuRadioGroupSignature {
    Args: {
        alignment?: 'inline';
        disabled?: AuRadioSignature['Args']['disabled'];
        name?: AuRadioSignature['Args']['name'];
        onChange?: AuRadioSignature['Args']['onChangeGroup'];
        selected?: AuRadioSignature['Args']['groupValue'];
    };
    Blocks: {
        default: [
            {
                Radio: WithBoundArgs<typeof AuRadio, 'name' | 'inGroup' | 'groupValue' | 'disabled' | 'onChangeGroup'>;
            }
        ];
    };
    Element: HTMLDivElement;
}
export default class AuRadioGroup extends Component<AuRadioGroupSignature> {
    uniqueName: string;
    get alignmentClass(): "" | "au-c-control-group--inline";
}
//# sourceMappingURL=au-radio-group.d.ts.map