import Component from '@glimmer/component';
import { type AuIconSignature } from './au-icon';
export interface AuLinkExternalSignature {
    Args: {
        hideText?: boolean;
        icon?: AuIconSignature['Args']['icon'];
        iconAlignment?: 'left' | 'right';
        newTab?: boolean;
        skin?: 'primary' | 'secondary' | 'bold' | 'button' | 'button-secondary' | 'button-naked';
        width?: 'block';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLAnchorElement;
}
export default class AuLinkExternal extends Component<AuLinkExternalSignature> {
    get skinClass(): string;
    get widthClass(): "" | "au-c-button--block" | "au-c-link--block";
    get isIconLeft(): boolean;
    get isIconRight(): boolean;
    get iconAlignment(): "left" | "right";
    get iconOnlyClass(): "" | "au-c-button--icon-only" | "au-c-link--icon-only";
    get newTab(): boolean;
}
//# sourceMappingURL=au-link-external.d.ts.map