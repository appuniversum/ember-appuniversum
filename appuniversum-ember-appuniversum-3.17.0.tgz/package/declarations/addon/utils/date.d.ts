export declare function formatDate(date: Date): string;
export declare function toIsoDateString(date: Date): string;
export declare function isIsoDateString(isoDate: string): boolean;
export declare function isValidDate(date: Date): boolean;
export declare function isoDateToBelgianFormat(isoDate: string): string;
//# sourceMappingURL=date.d.ts.map