export declare function isElement(node?: Node | null): node is Element;
export declare function isHtmlElement(node?: Node | null): node is HTMLElement;
//# sourceMappingURL=is-element.d.ts.map